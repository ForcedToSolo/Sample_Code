/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.sample.custom.text2edms.bootstrap;

import com.documentum.fc.client.IDfSession;

/**
 *
 * @author crittedp
 */
public interface IText2EDMS
{
/*    public void init(IDfSession session);
    public boolean run(String[] args);
*/
    public boolean init(String strDocbase, String strLogicDocbase, String strScriptName, String strLogFile,IDfSession session) throws Exception;
    public boolean run(String[] args) throws Exception;
    public int getSuccesses();
    public int getFailures();
    public int getTotalAttachments();
    public boolean getDebugMode();
}
