package com.sample.custom.text2edms.bootstrap;


import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.fc.tools.*;
import java.io.*;
import java.net.*;
import java.security.*;

/**
 * Initial class that drives the entire program.
 *
 * @author crittedp
 */
public class Text2EDMSBootstrap
{
    private IDfSession SESSION = null;
    private BufferedReader in = null;
    private boolean ERASE_INPUT = true;

    // Exit status of the program
    private enum ExitStatus
        {
            SUCCESS,                            // 0
            ERROR_NO_ATTACHMENTS_SUCCEEDED,     // 1
            ERROR_SOME_ATTACHMENTS_SUCCEEDED    // 2
        }

    /**
     * This class is a workaround to java 5's inability to not display passwords
     * as their typed.
     */
    class ConsoleEraser extends Thread
    {
        /**
         * This method starts & stops a thread to automatically delete the
         * password characters as they're entered by the user.
         */
        @Override
        public void run()
        {
            ERASE_INPUT = true;
            while (ERASE_INPUT)
            {
                System.err.print("\b ");
            }
        }

        /**
         * This method causes the run() method to end.
         */
        public synchronized void halt()
        {
            ERASE_INPUT = false;
        }
    }

    /**
     * This constructor drives the entire program. It performs the following actions:
     *  <ul>
     *      <li> Reads System properties set by the UNIX wrapper
     *      <li> Creates the base directory structure for the program in the user's home dir
     *      <li> Log in to EDMS using the user-provided credentials
     *      <li> Update user's the Text2EDMS.jar if necessary
     *      <li> Launch the Text2EDMS program
     * </ul>
     *
     * @param    args        The command line arguments
     *
     */
    public Text2EDMSBootstrap(String[] args)
    {
        ExitStatus enumExitStatus = ExitStatus.ERROR_NO_ATTACHMENTS_SUCCEEDED;
        IText2EDMS t2e = null;
        try 
        {
            boolean boolLoggedIn;
            boolean boolUserInfoFileExists;
            boolean boolLoginAttemptUsingFile = false;
            
            IDfLoginInfo login = null;
            int intAttempts;
            String strDocbase = System.getProperty("t2e.docbase").trim();
            String strLogicDocbase = System.getProperty("t2e.logic").trim();
            String strFileSeparator = File.separator;
            String strT2EJar = System.getProperty("t2e.jar").trim();
            String strT2EScript = System.getProperty("t2e.script").trim();
            File dirUserT2EHome = new File(System.getProperty("t2e.home").trim());
            File dirUserT2ELog = new File(System.getProperty("t2e.log").trim());
            File dirUserT2ELib = new File(System.getProperty("t2e.lib").trim());
            File dirUserT2EInfo = new File(System.getProperty("t2e.info").trim());
            File fileUserInfo = new File(System.getProperty("t2e.info").trim() + strFileSeparator + "." + strDocbase);
            File fileUserT2EJar = new File(strT2EJar);

            //
            // Check to see if the base directory & all associated files exist
            //
            createDirectoryStructure(dirUserT2EHome, dirUserT2EInfo, dirUserT2ELib, dirUserT2ELog);
            
            //
            // Loop, 1st getting the user info,
            // 2nd trying to log in with that user info
            //
            boolLoggedIn = false;
            intAttempts = 1;
            boolUserInfoFileExists = fileUserInfo.exists();
            while(!boolLoggedIn && intAttempts <= 3)
            {
                // Get the user info to login, i.e., user name and password
                if (intAttempts == 1 && boolUserInfoFileExists)
                { // 1st time and user info file exists
                    // so read in user info from the file
                    login = readUserInfoFile(fileUserInfo);
                    boolLoginAttemptUsingFile = true;
                } // 1st time and user info file exists
                else
                { // Subsequent time (1st time failed) or no user info file
                    // so prompt the user for the login info 
                    login = requestLogin(intAttempts > 1);
                    boolLoginAttemptUsingFile = false;
                } // Subsequent time (1st time failed) or no user info file

                // Try to login
                try
                {
                    setEDMSSession(loginToEDMS(login, strDocbase));
                    if(getEDMSSession() != null)
                    {
                        boolLoggedIn = true;
                    }
                }
                catch(Exception e)
                {
                    System.err.println("[ERROR] Authentication failed with error: " + e.toString());
                }
                intAttempts++;
            }
            //
            // Check to see if we exited the loop due to max attempts.
            // Because of the condition in the previous while loop,
            // if boolLoggedIn is false, then intAttempts > 3
            //
            if(!boolLoggedIn)
            {
                if (boolUserInfoFileExists)
                    fileUserInfo.delete();
                
                System.err.println("[ERROR] Maximum number of login attempts reached" );
                System.err.println("[ERROR] Failed to log in. Terminating program.");
                enumExitStatus = ExitStatus.ERROR_NO_ATTACHMENTS_SUCCEEDED;
            }
            else
            {
                //
                // Create the user info file
                //
                if(!boolLoginAttemptUsingFile && 
                    !getEDMSSession().getUserByLoginName(login.getUser(), null).isSuperUser() &&
                    !login.getUser().equalsIgnoreCase("dmadmin") &&
                    getEDMSSession().getUserByLoginName(login.getUser(), null).getUserName().contains(" "))
                {
                    createT2EInfo(fileUserInfo,login);
                }
                //
                // Check for updates to the Text2EDMS JAR file
                //
                try
                {
                    if(needJarUpdate(fileUserT2EJar))
                    {
                        doJarUpdate(fileUserT2EJar);
                    }
                }
                catch(Exception e)
                {
                    throw new Exception("An error has been encountered while updating text2edms", e);
                }

                //
                // Load the text2edms jar
                //
                URL myJarFile = new URL("jar:file://" + fileUserT2EJar.getPath().trim() + "!/");
                URLClassLoader loader = new URLClassLoader(new URL[]{myJarFile});
                Class c = loader.loadClass("com.sample.custom.text2edms.program.Text2EDMS");

                //
                // Launch Text2EDMS
                //
                String strLogFile = dirUserT2ELog.getPath() + File.separator + strT2EScript + ".log";
                t2e = (IText2EDMS)c.newInstance();

                t2e.init(strDocbase, strLogicDocbase, strT2EScript, strLogFile, getEDMSSession());

                if(t2e.run(args))
                {
                    if(t2e.getTotalAttachments() > 0)
                    {
                        if(t2e.getFailures() == 0)
                        {
                            enumExitStatus = ExitStatus.SUCCESS;
                        }
                        else if(t2e.getSuccesses() == 0)
                        {
                            enumExitStatus = ExitStatus.ERROR_NO_ATTACHMENTS_SUCCEEDED;
                        }
                        else
                        {
                            enumExitStatus = ExitStatus.ERROR_SOME_ATTACHMENTS_SUCCEEDED;
                        }
                    }
                    else
                    {
                        enumExitStatus = ExitStatus.ERROR_NO_ATTACHMENTS_SUCCEEDED;
                    }
                }
                else
                {
                    enumExitStatus = ExitStatus.ERROR_NO_ATTACHMENTS_SUCCEEDED;
                }

                if(t2e.getSuccesses() + t2e.getFailures() > 0)
                {
                    System.out.println("Attachment process complete.\n" +
                                "Total Attachments Processed: " + t2e.getTotalAttachments() + "\n" +
                                "Total Errors: " + t2e.getFailures() + "\n" +
                                "Total Successes: " + t2e.getSuccesses() + "\n");
                }

            }
        }
        catch (Exception e)
        {
            displayException(e, args);
        }
        finally
        {
            if (getEDMSSession() != null)
            {             
                try 
                { 
                    getEDMSSession().disconnect();
                    
                } catch (Exception e) {}
            }
            if (in != null)
            {
                try { in.close(); } catch (IOException e) {}
            }
            System.exit(enumExitStatus.ordinal());
        }          
    }

    /**
     * This method requests the login information from the user. It reads in
     * the user's name & password and returns that information in the form of an
     * IDfLoginInfo object.
     *
     * @param boolAuthenticationFailed  Boolean used to determine printed output
     *
     * @return IDfLoginInfo     Object containing the user's login information
     */
    private IDfLoginInfo requestLogin(boolean boolAuthenticationFailed)
    {             
        IDfLoginInfo login = new DfLoginInfo();
        try 
        { 
            Console cons = System.console();
            if (cons == null)
            {
                //  prompt the user to enter their name
                if(!boolAuthenticationFailed)
                {
                    System.err.println("No login information found:");
                    System.err.println("You must provide your EDMS login information.");
                }
                else
                {
                    System.err.println("Authentication failed, please try again:");             
                }

                //  prompt the user to enter their name
                System.err.println("EDMS Username: ");

                //  open up standard input
                in = new BufferedReader(new InputStreamReader(System.in));

                //  read the username & PW from the command line
                login.setUser(in.readLine().toLowerCase().trim());
                ConsoleEraser consoleEraser = new ConsoleEraser();
                System.err.println("EDMS Password:");
                consoleEraser.start();
                String strPW = in.readLine();
                consoleEraser.halt();
                System.err.print("\b ");
                login.setPassword(strPW.trim());
            } 
            else
            {
                //  prompt the user to enter their name
                if(!boolAuthenticationFailed)
                {
                    cons.format("No login information found:\n");
                    cons.format("You must provide your EDMS login information.\n");
                }
                else
                {
                    cons.format("Authentication failed, please try again:\n");             
                }

                //  read the username & PW from the command line
                login.setUser(cons.readLine("EDMS Username: \n").toLowerCase().trim());
                char[] arrPW = cons.readPassword("EDMS Password:\n");
                if (arrPW == null)
                    login.setPassword("");
                else
                    login.setPassword(new String(arrPW).trim());
            } 
        }
        catch (Exception e) 
            {
                System.err.println("[ERROR] Unknown error: ");
                System.err.println("[MESSAGE] " + e.getMessage());
                //e.printStackTrace();
            }        
        return login;
    }

    /**
     * This method reads the user's encrypted login information from a file.
     *
     * @param   fileUserInfo    The file containing the user's information
     *
     * @return IDfLoginInfo     Object containing the user's login information
     */
    private IDfLoginInfo readUserInfoFile(File fileUserInfo)
    {
        BufferedReader reader = null;
        IDfLoginInfo login = new DfLoginInfo();
        try
        {
            reader = new BufferedReader(new FileReader(fileUserInfo));
            String strText = "";
            int count = 0;

            //
            // repeat until all lines are read
            //
            while ((strText = reader.readLine()) != null)
            {
                if(strText.length() == 0 )
                {
                    continue;
                }
                if(count == 0)
                {
                    login.setUser(RegistryPasswordUtils.decrypt(strText.trim()));
                }
                else if(count == 1)
                {
                    login.setPassword(RegistryPasswordUtils.decrypt(strText.trim()));
                }
                count++;
            }
        }
        catch (Exception e)
        {
            System.err.println("[ERROR] Unknown error: " + e.getMessage());
        }
        finally
        {
            if (reader != null)
            {
                try {reader.close();} catch (IOException ex) {}
            }            
        }

        return login;
    }

    /**
     * This function attempts to the user into the docbase.
     *
     * @param   login   Object containing the user's login information
     * @param   strDocbase  The docbase where the session will be created
     *
     * @return IDfSession   The user's session to the docbase. May be null if
     *                      the login attempt failed.
     */
    private IDfSession loginToEDMS(IDfLoginInfo login, String strDocbase) throws Exception
    {
        IDfClient client = null;
        
        //
        // Establish a session to the docbase
        //
        client = DfClient.getLocalClient();
        return client.newSession(strDocbase, login);
    }

    /**
     * The main class of the program.
     *
     * @param   args  Command line arguments
     *
     */
    public static void main(String[] args)
    {      
        new Text2EDMSBootstrap(args);
    }

    /**
     * This method creates the file that stores the user's encrypted login information.
     *
     * @param   fileUserInfo    File object to store the user's information
     * @param   login   Object containing the user's information
     *
     */
    private void createT2EInfo(File fileUserInfo, IDfLoginInfo login) throws Exception
    {
        try
        {    
            // If the file already exists, it will be overwritten
            PrintWriter outFile = new PrintWriter(fileUserInfo);
            outFile.println(RegistryPasswordUtils.encrypt(login.getUser()));
            outFile.println(RegistryPasswordUtils.encrypt(login.getPassword()));
            outFile.close();
        }
        catch (Exception e)
        {
            throw new Exception("Could not create user info file \"" + fileUserInfo.getAbsolutePath() + "\"", e);
        }
    }

    /**
     * This function creates the directory structure utilized by the text2edms
     * program. The following directories are created under the user's home area:
     * /.text2edms.<user>name/
     *                       /lib
     *                       /info
     *                       /logs
     *
     * @param   dirUserT2EHome  This is the hidden text2edms directory
     * @param   dirUserT2EInfo  The user's login information folder
     * @param   dirUserT2ELogs  The log directory
     */
    private void createDirectoryStructure(File dirUserT2EHome, File dirUserT2EInfo, File dirUserT2ELib, File dirUserT2ELogs) throws Exception
    {
        File dirUserHome = new File(System.getProperty("user.home").trim());
        if(!dirUserHome.canWrite())
        {
            throw new Exception("No write permissions on " + dirUserHome.getPath());
        }
        createDirectory(dirUserT2EHome);
        createDirectory(dirUserT2EInfo);
        createDirectory(dirUserT2ELib);
        createDirectory(dirUserT2ELogs);
    }
    
    /**
     * Create a system directory, throwing an error if unsuccessful
     * @param dirToCreate directory to be created
     * @throws Exception 
     */
    private void createDirectory(File dirToCreate) throws Exception
    {
        boolean boolThrowException = false;
        Exception exceptionCause = null;
        try
        {
            if (! dirToCreate.exists() && ! dirToCreate.mkdir())
                boolThrowException = true;
        }
        catch (Exception e)
        {
            boolThrowException = true;
            exceptionCause = e;
        }
        if (boolThrowException)
        {
            throw new Exception("Could not create system directory \""
                    + dirToCreate.getAbsolutePath() + "\"", exceptionCause);
        }
    }
    

    /**
     * This function determines if the user's text2edms.jar file needs to be
     * updated. This is determined by comparing the MD5 checksum of the
     * user's local jar file to the checksum of the jar stored in EDMS. The EDMS
     * checksum value is stored in the 'subject' attribute of the EDMS object.
     *
     * @param   fileUserT2EJar  The user's local copy of the code.
     *
     * @return  True if the local jar needs to be updated.
     */
    private boolean needJarUpdate(File fileUserT2EJar) throws Exception
    {
        boolean boolNeedUpdate = false;

        if(!fileUserT2EJar.exists())
        {
            boolNeedUpdate = true;
        }
        else
        {
            IDfSysObject edmsJar = (IDfSysObject) getEDMSSession().getObjectByQualification("dm_document WHERE object_name='text2edms' " +
                                                                                   "AND folder('/dmadmin/text2edms')");
            if(edmsJar != null)
            {
                String strStoredChecksum = edmsJar.getSubject();
                try
                {
                    String strComputedChecksum = computeMD5Checksum(fileUserT2EJar.getAbsolutePath());
                    if (!strStoredChecksum.equals(strComputedChecksum))
                    {
                        boolNeedUpdate = true;
                    }
                }
                catch(Exception e)
                {
                    //
                    // If we fail to compute the checksum, update by default.
                    //
                    boolNeedUpdate = true;
                }
            }
        }
        
        return boolNeedUpdate;
    }

    /**
     * This function computes the MD5 checksum value of the user's local t2e.jar.
     *
     * @param   strFile     The path to the user's local jar file.
     *
     * @return  The string representation of the checksum.
     */
    private static String computeMD5Checksum(String strFile) throws Exception
    {
        byte[] buf = new byte[1024];
        FileInputStream fin = new FileInputStream(strFile);
        MessageDigest md5sum = MessageDigest.getInstance("MD5");

        int len;
        while ((len = fin.read(buf)) > 0)
        {
            md5sum.update(buf, 0, len);
        }

        fin.close();

        String result = "";
        byte[] bytesum = md5sum.digest();
        for (int i = 0; i < bytesum.length; i++)
        {
            result += Integer.toString((bytesum[i] & 0xff) + 0x100, 16).substring(1);
        }

        return result;
    }

    /**
     * This method performs the update to the user's local text2edms.jar file.
     * This basically copies the updated file from EDMS to the user's local lib
     * directory.
     *
     * @param fileUserT2EJar    The user's local t2e jar file
     *
     */
    private void doJarUpdate(File fileUserT2EJar) throws Exception
    {
        //
        // Delete the local file since it needs to be updated
        //
        if(fileUserT2EJar.exists())
        {
            fileUserT2EJar.delete();
        }

        //
        // Look up the T2E Jar file from EDMS. Copy its content to the local
        // lib directory
        //
        
        IDfSysObject edmsJar = (IDfSysObject) getEDMSSession().getObjectByQualification("dm_document where object_name='text2edms' " +
                                                                               "AND folder('/dmadmin/text2edms')");
        //Uncomment the next line and comment the remaining lines in this method for production
        File fileEDMSJar = new File(edmsJar.getFile(fileUserT2EJar.getPath()));
        //System.out.println("EDMS JAR: " + fileEDMSJar.getPath() + "    exists: " + fileEDMSJar.exists());

        ////////////////////////////////////////////////////////////////////////
        // TESTING: This uses the freshly compiled JAR file instead of the EDMS
        // copy. This makes the testing process easier. Comment all this out
        // when you want to actually use the EDMS JAR file.
        ////////////////////////////////////////////////////////////////////////
//        File fileEDMSJar = new File("/usr/local/bin/edms/text2edms/build/lib/text2edms.jar");
//        InputStream inStream = new FileInputStream(fileEDMSJar);
//        OutputStream outStream = new FileOutputStream(fileUserT2EJar);
//
//        byte[] buf = new byte[1024];
//        int len;
//        while ((len = inStream.read(buf)) > 0)
//        {
//            outStream.write(buf, 0, len);
//        }
//
//        inStream.close();
//        outStream.close();
    }
   
    /**
     * Display any exception message.  If a command-line option is "-debug" then
     * print a stack trace, otherwise print the exception message including any
     * exception causes
     * @param baseException     exception to be displayed
     * @param arrProgramOptions command-line arguments to search for "-debug"
     */
    private void displayException(Exception baseException, String[] arrProgramOptions)
    {
        // Look for "-debug" as one of the command line options.  Do a quick-and-dirty
        // search through the options, because the error may be occurring before
        // the options have been properly parsed
        boolean boolDebug = false;
        for (int i = 0; i < arrProgramOptions.length && ! boolDebug; i++)
        {
            if (arrProgramOptions[i].equals("-debug"))
               boolDebug = true;
        }
        
        System.err.println("[ERROR] An error has occurred: ");
       
        // If "-debug" then print the error and stack trace (including all
        // its causes), which could be long
        if (boolDebug)
        {
            baseException.printStackTrace();
        }
        else
        {
            // Not "-debug", just print out the error message
            // (and indent any causes)
            boolean boolFirstLine = true;
            for (Throwable t = baseException; t != null; t = t.getCause())
            {
                String strIndent;
                if (boolFirstLine)
                    strIndent = "";
                else
                    strIndent = "    ";
                System.err.println(strIndent + t.toString());
                boolFirstLine = false;
            }
        }
        
        System.err.println(" Terminating. ");
    }

    /**
     * This method sets the global 'SESSION' to the EDMS session establish during
     * log in.
     *
     * @param edmsSess  The user's EDMS session object
     *
     */
    public void setEDMSSession(IDfSession edmsSess)
    {
        SESSION = edmsSess;
    }

    /**
     * This method returns the EDMS session object.
     *
     * @return IDfSession   The EDMS session object.
     */
    public IDfSession getEDMSSession()
    {
        return SESSION;
    }      
        
}
    
    
    
    

