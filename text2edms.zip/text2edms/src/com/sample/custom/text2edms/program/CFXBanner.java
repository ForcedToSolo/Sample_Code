/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.sample.custom.text2edms.program;


/**
 *
 * @author crittedp
 */
public class CFXBanner extends T2EBanner
{

    @Override
    public void processParsedAttributes() throws Exception
    {
        String strProgramVerified = (String)getParsedAttributes().remove("att_program_verified");
        String strProgramVersion = (String)getParsedAttributes().get("att_program_version");
        String strConfigDate = (String)getParsedAttributes().get("att_configure_date");
        String strExecID = (String)getParsedAttributes().remove("att_exec_id");
        String strProgramStatus = "UNCONFIGURED";

        if(strExecID != null)
        {   LogUtils.printDebug("      Removing non-numerics from execution id '" + strExecID + "'");
            strExecID = strExecID.replaceAll( "[\\D]", "");
            if(strExecID.length() > 0)
            {
                setParsedAttributes("att_exec_id", strExecID, false);
            }
        }
        LogUtils.printDebug("      Calculating Program Status");
        LogUtils.printDebug("         Config Date: " + strConfigDate);
        LogUtils.printDebug("         Program Status: " + strProgramStatus);
        LogUtils.printDebug("         Program Version: " + strProgramVersion);
        LogUtils.printDebug("         Program Verified: " + strProgramVerified);
        if(strConfigDate != null)
        {
            if(strProgramVerified != null)
            {
                strProgramStatus = "T-CONFIGURED";
                strProgramVersion = strProgramVersion + "-" + strProgramVerified;
                setParsedAttributes("att_program_version", strProgramVersion, false);
            }
            else
            {
                strProgramStatus = "CONFIGURED";
            }
        }
        setParsedAttributes("att_program_status", strProgramStatus, false);
    }

}