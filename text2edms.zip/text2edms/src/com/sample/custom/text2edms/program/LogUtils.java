

package com.sample.custom.text2edms.program;

import java.util.*;
import java.io.*;
import java.text.*;

/**
 * Convenience class to handle logging functions
 *
 */
public class LogUtils
{
    //
    // Whether debug messages will be displayed
    //
    private static final boolean DEBUG = Text2EDMS.getDebug();
    //
    // Date format for the log messages
    //
    private static final String DATE_FORMAT = "MM-dd-yyyy hh:mm:ss aa";

    /**
     * Called to start the log when the application starts
     *
     * @throws  FileNotFoundException   If the log file cannot be found
     */
    public static void startLog()
                                throws FileNotFoundException
    {
        if (DEBUG) printDebug("*** Started Text2EDMS ***");
    }

    /**
     * Called to end the log when the application ends
     *
     * @throws  FileNotFoundException   If the log file cannot be found
     */
    public static void endLog()
                              throws FileNotFoundException
    {
        if (DEBUG) printDebug("*** Ended Text2EDMS ***\n");
    }

    /**
     * Used to handle an error message when an Exception is thrown
     *
     * @param   strMessage              The error message
     * @param   e                       The exception, can be null
     * @throws  FileNotFoundException   If the log file cannot be found
     */
    public static void handleError(String strMessage, Exception e)
                                   throws FileNotFoundException
    {
        LogUtils.printMsg(strMessage);
        if (e != null && e.getMessage() != null)
        {
            LogUtils.printMsg("[MESSAGE] " + e.getMessage());
            if(DEBUG)
            {
                e.printStackTrace();
            }
        }
    }
    /**
     * Same as calling handleError(strMessage, null)
     *
     * @param   strMessage              The error message
     * @throws  FileNotFoundException   If the log file cannot be found
     */
    public static void handleError(String strMessage)
                                   throws FileNotFoundException
    {
        handleError(strMessage, null);
    }

    /**
     * Prints a debug message to the log with the date and time then prints the
     * message to the standard output. Does nothing if debug is set to false.
     *
     * @param   strMessage              The debug message
     * @throws  FileNotFoundException   If the log file cannot be found
     */
    public static void printDebug(String strMessage)
                                throws FileNotFoundException
    {
        if(DEBUG)
        {
            PrintStream fout = new PrintStream(new FileOutputStream(Text2EDMS.getLogFile(), true));
            String strNow = new SimpleDateFormat(DATE_FORMAT).format(Calendar.getInstance().getTime());
            fout.println(strNow + " " + strMessage);
            fout.close();
            
            System.out.println(strMessage);
        }
        
    }
    /**
     * Prints a message to the standard output. If the program is in debug mode
     * the message will be passed to printDebug instead.
     *
     * @param   strMessage              The log message to print
     * @throws  FileNotFoundException   If the log file cannot be found
     */
    public static void printMsg(String strMessage)throws FileNotFoundException
    {       
        if(DEBUG)
            printDebug(strMessage);
        else
            System.out.println(strMessage);
    }
}