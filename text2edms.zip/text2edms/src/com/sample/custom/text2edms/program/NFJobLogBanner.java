/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.sample.custom.text2edms.program;

import java.util.*;
import java.util.regex.*;

/**
 *
 * @author crittedp
 */
public class NFJobLogBanner extends T2EBanner
{
    private boolean IS_SECONDARY_BANNER = false;

    @Override
    public boolean init(int strBnrNum, String strBannerDocbase) throws Exception
    {
        if(super.init(strBnrNum, strBannerDocbase));
        {
            setIsSecondaryBanner();
            return true;
        }
    }

    /*
     * ParseLine 
     */
    
    @Override
    public boolean parseLine(String strLine) throws Exception
    {
        Pattern pattern = null;
        Matcher matcher = null;
        Pattern patBannerStart = Pattern.compile(getBannerStartPattern());
        Pattern patBannerEnd = Pattern.compile(getBannerEndPattern());

        //
        // If this banner has been selected
        //
        if(isSelected())
        {
            if(getRegexPattern() != null)
            {
                pattern = Pattern.compile(getRegexPattern().trim());
                matcher = pattern.matcher(strLine);
               //matcher.reset(strLine);
               LogUtils.printDebug("      Regex: " + pattern.pattern());
               if(matcher.find())
               {
                   LogUtils.printDebug("         Found!");
                   int numGroups = matcher.groupCount();
                   String strAttributeName = "";

                   if(getRegexAttributeCount() > 0)
                   {
                       if (getRegexAttributeCount() == numGroups)
                       {
                           for(int x=1; x <= numGroups; x++)
                           {
                                 strAttributeName = getRegexAttr(x);
                                 setParsedAttributes(strAttributeName, matcher.group(x), getRegexAttrRepeating(x));
                           }
                       }
                       else
                       {
                           //Do nothing
                       }
                   }
                   else
                   {
                       LogUtils.printDebug("      No attributes to parse");
                   }

                   /*
                    * We always increment the REGEX_POSITION if we've entered the
                    * "matched" block, even if we don't successfully parse the values
                    * from the input. This ensures the regex changes everytime
                    * instead of getting hung up on a single pattern.
                    */
                   incrementRegexPosition();

                    if(getRegexPosition() > getRegexCount())
                    {
                        if(isSecondaryBanner())
                        {
                            //
                            // This banner repeats itself until the BANNER_END_PATTERN is found.
                            //
                            LogUtils.printDebug("         Resetting the regex position to 1!");
                            overrideRegexPosition(1);
                            setRegexPattern();
                            setRegexAttributeCount();
                        }
                        else
                        {
                            LogUtils.printDebug("         Maximum number of regexs reached!");
                            setFinished(true);
                        }
                    }
                    else
                    {
                       setRegexPattern();
                       setRegexAttributeCount();
                    }
                }
                else
                {
                   /*
                    * Always check to see if we've reached the end of the banner
                    * if the current input does not match the regex.
                    */
                    LogUtils.printDebug("            No match!");
                    if(testBannerEnd(patBannerEnd.matcher(strLine).find()))
                    {
                        LogUtils.printDebug("      Banner End Reached");
                        setFinished(true);
                    }
               }
            }
            else if(testBannerEnd(patBannerEnd.matcher(strLine).find()))
            {
                LogUtils.printDebug("      Banner End Reached");
                setFinished(true);
            }
            //
            // Log that the current line didn't match the regex but return true
            // to continue the process. The current regex will be searched for
            // until either it is found or the end of the banner is encountered.
            // 
            return true;
        }
        else
        {
            /*
             * If the isSelected == false then compare the current input line
             * to the banner's identification regex. Set isSelected() based on
             * the comparison
             */
            setSelected(testBannerStart(patBannerStart.matcher(strLine).find()));
            return isSelected();
        }
    }

    



    @Override
    public void processParsedAttributes() throws Exception
    {
        
        if(!isSecondaryBanner())
        {
            String strExecMonthDay = (String)getParsedAttributes().remove("exec_month_day");
            String strExecYear = (String)getParsedAttributes().remove("exec_year");
            String strServerName = (String)getParsedAttributes().get("att_server_name");
            String strDQSJobID = (String)getParsedAttributes().get("att_dqs_jobid");
            LogUtils.printDebug("      Calculating execution date:");
            LogUtils.printDebug("         Execution Month/Day: '" + strExecMonthDay + "'");
            LogUtils.printDebug("         Execution Year: '" + strExecYear + "'");

            if(strExecMonthDay != null && strExecYear != null)
            {
                try
                {
                    if(strExecYear.length() < 4)
                    {
                        Integer intYear = new Integer(strExecYear);
                        if(intYear < 50)
                        {
                            strExecYear = "20" + strExecYear;
                        }
                        else
                        {
                            strExecYear = "19" + strExecYear;
                        }
                    }
                    String strExecDate = strExecMonthDay + strExecYear;
                    setParsedAttributes("att_exec_date", strExecDate, false);
                }
                catch(Exception e)
                {
                    throw e;
                }
            }
            LogUtils.printDebug("      Determining server name:");
            LogUtils.printDebug("         Server Name: '" + strServerName + "'");
            LogUtils.printDebug("         DQS ID: '" + strDQSJobID + "'");
            if(strServerName != null && strServerName.length() > 0 )
            {
                if(strDQSJobID != null && strDQSJobID.length() > 0)
                {
                    setParsedAttributes("att_dqs_jobid", strServerName + "_" + strDQSJobID, false);
                }
                else
                {
                    setParsedAttributes("att_dqs_jobid", strServerName + "_", false);
                }

            }
        }
        else
        {
            List<String> arrTempName = T2EConfig.toGenericList((List)getParsedAttributes().get("att_program_namer"));
            List<String> arrTempVersion = T2EConfig.toGenericList((List)getParsedAttributes().get("att_program_versionr"));
            List<String> arrTempStatus = T2EConfig.toGenericList((List)getParsedAttributes().get("att_program_statusr"));
            List<String> arrTempConfigDate = T2EConfig.toGenericList((List)getParsedAttributes().get("att_configure_dater"));

            if(getBannerDocbase().equalsIgnoreCase("docnfd"))
            {
                LogUtils.printDebug("         Processing NFD Repeating attributes:");

                //
                // Remove repeating entries (where name & version match) if all
                // arrays are the same size and not null. Otherwise just leave
                // them alone.
                //
                if( (arrTempName != null && arrTempVersion != null
                    && arrTempStatus != null && arrTempConfigDate != null)
                    && (arrTempName.size() == arrTempVersion.size()
                       && arrTempName.size() == arrTempStatus.size()
                       && arrTempName.size() == arrTempConfigDate.size()))
                {
                    List<String> arrUniqueName = new Vector<String>();
                    List<String> arrUniqueVersion = new Vector<String>();
                    List<String> arrUniqueStatus = new Vector<String>();
                    List<String> arrUniqueConfigDate = new Vector<String>();
                    LogUtils.printDebug("            Ensuring Unique Entries:");
                    for(int x=0; x<arrTempName.size(); x++)
                    {
                        boolean boolAddRecord = true;
                        String strTempName = arrTempName.get(x);
                        String strTempVersion = arrTempVersion.get(x);
                        LogUtils.printDebug("            Testing name: '" + strTempName + "' Version: '" + strTempVersion + "'");
                        if(arrUniqueName.contains(strTempName))
                        {
                            for(int y=0; y<arrUniqueName.size(); y++)
                            {
                                String strUniqueName = arrUniqueName.get(y);
                                String strUniqueVersion = arrUniqueVersion.get(y);
                                if(strUniqueName.equalsIgnoreCase(strTempName))
                                {
                                    if(strUniqueVersion.equalsIgnoreCase(strTempVersion))
                                    {
                                        LogUtils.printDebug("               FAIL - Skipping entry");
                                        boolAddRecord = false;
                                        break;
                                    }
                                     else
                                    {
                                        LogUtils.printDebug("                  PASS");
                                    }
                                }                              
                            }
                        }
                        if(boolAddRecord)
                        {
                            LogUtils.printDebug("                  Adding entry");
                            arrUniqueName.add(arrTempName.get(x));
                            arrUniqueVersion.add(arrTempVersion.get(x));
                            arrUniqueStatus.add(arrTempStatus.get(x));
                            arrUniqueConfigDate.add(arrTempConfigDate.get(x));
                        }
                    }
                    LogUtils.printDebug("               Complete - Updating Parsed Attributes tables");
                    getParsedAttributes().put("att_program_namer",arrUniqueName);
                    getParsedAttributes().put("att_program_versionr",arrUniqueVersion);
                    getParsedAttributes().put("att_program_statusr",arrUniqueStatus);
                    getParsedAttributes().put("att_configure_dater",arrUniqueConfigDate);
                }
            
                //
                // Process the configuration dates...convert them from 2 digit years to 4
                //
                arrTempConfigDate = T2EConfig.toGenericList((List)getParsedAttributes().get("att_configure_dater"));
                if(arrTempConfigDate != null)
                {
                    List<String> arrFormattedDates = new Vector<String>();
                    for(String strConfigDate : arrTempConfigDate)
                    {
                        LogUtils.printDebug("         Encountered Config Date: " + strConfigDate);
                        if(strConfigDate.indexOf("/") > 0)
                        {
                            try
                            {
                                String strYear = strConfigDate.substring(strConfigDate.lastIndexOf("/") + 1);
                                String strMonthDay = strConfigDate.substring(0, strConfigDate.lastIndexOf("/") + 1);
                                if(strYear.length() < 4)
                                {
                                    Integer intYear = new Integer(strYear);
                                    if(intYear < 80)
                                    {
                                        strYear = "20" + strYear;
                                    }
                                    else
                                    {
                                        strYear = "19" + strYear;
                                    }
                                    strConfigDate = strMonthDay + strYear;
                                }
                            }
                            catch(Exception e)
                            {
                                throw e;
                            }
                        }
                        LogUtils.printDebug("         Calculated Config Date: " + strConfigDate);
                        arrFormattedDates.add(strConfigDate);
                    }
                    getParsedAttributes().put("att_configure_dater",arrFormattedDates);
                }

                //
                // Process the program status - determine the status based on the file path
                //
                arrTempStatus = T2EConfig.toGenericList((List)getParsedAttributes().get("att_program_statusr"));
                if(arrTempStatus != null)
                {
                    Hashtable<String,String> hStatusInfo = getStatusInformation();
                    String strDefault = hStatusInfo.remove("default");
                    List<String> arrFormattedStatus = new Vector<String>();

                    for(String strTempStatus : arrTempStatus)
                    {
                        String strFormattedStatus = strDefault;
                        Enumeration<String> keys = hStatusInfo.keys();
                        LogUtils.printDebug("         Encountered Status: " + strTempStatus);
                        while (keys.hasMoreElements())
                        {
                            String strPath = keys.nextElement();
                            if(strTempStatus.contains(strPath))
                            {
                                strFormattedStatus = hStatusInfo.get(strPath);
                            }
                        }
                        LogUtils.printDebug("         Mapped Status: " + strFormattedStatus);
                        arrFormattedStatus.add(strFormattedStatus);
                    }
                    getParsedAttributes().put("att_program_statusr", arrFormattedStatus);
                }
            }
            else
            {
                LogUtils.printDebug("         Upload docbase is not docnfd. Removing docnfd specific repeating attributes");
                getParsedAttributes().remove("att_program_namer");
                getParsedAttributes().remove("att_program_versionr");
                getParsedAttributes().remove("att_program_statusr");
                getParsedAttributes().remove("att_configure_dater");
            }
        }     
    }

    /*
     * Special NFD banner processing
     */
    public void setIsSecondaryBanner()
    {
        IS_SECONDARY_BANNER = T2EConfig.getConfigBoolean("banner." + getBannerNumber() + ".secondary.only" , false);
    }
    private boolean isSecondaryBanner() 
    {
        return IS_SECONDARY_BANNER;
    }
    private Hashtable<String,String> getStatusInformation() 
    {
        Hashtable<String,String> hTable = new Hashtable<String,String>();
        int intStatusCount = T2EConfig.getConfigInteger("banner." + getBannerNumber() + ".status.count", 0);
        String strDefault = T2EConfig.getConfigString("banner." + getBannerNumber() + ".status.default");
        if(strDefault != null)
        {
            hTable.put("default", strDefault);
        }
        for(int x=1; x <= intStatusCount; x++)
        {
            String strPath = T2EConfig.getConfigString("banner." + getBannerNumber() + ".status." + x + ".path");
            String strValue = T2EConfig.getConfigString("banner." + getBannerNumber() + ".status." + x + ".value");
            if(strPath != null && strValue != null)
            {
                hTable.put(strPath, strValue);
            }            
        }
        return hTable;
    }
}