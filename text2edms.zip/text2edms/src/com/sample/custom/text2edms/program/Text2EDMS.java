/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.sample.custom.text2edms.program;

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.sample.custom.text2edms.bootstrap.IText2EDMS;
import java.io.*;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.*;
import jonelo.jacksum.*;
import jonelo.jacksum.algorithm.AbstractChecksum;

/**
 * Class to handle the processing & upload of attachments'
 *
 * @author crittedp
 */
public class Text2EDMS implements IText2EDMS
{
    private boolean P_PARSE_ONLY = false;
    private boolean F_USE_CL_NO_PARSE = false;
    private boolean f_FORCE_CL_OVER_PARSE = false;
    private boolean C_GENERATE_CL_OPTS = false;
    private boolean ZIP_ATTACHMENTS = false;
    private static boolean DEBUG = false;
    private String DOCBASE = "";
    private String DOCBASE_LOGIC = "";
    private IDfSession SESSION = null;
    private IDfSysObject EDMS_DOC = null;
    private static String LOG_FILE = "";
    private String SCRIPT_NAME = "";
    private int SUCCESS = 0;
    private int FAILURES = 0;
    private int TOTAL_ATTACH = 0;

    /**
     * This private class is used to store the information for the attachments.
     *
     * @param   None
     *
     */
    private class Attachment
    {
        public Hashtable<String,Object> ATTRIBUTES = new Hashtable<String,Object>();
        public String FORMAT = "";
        public String NAME = "";
        public String PATH = "";
        public int CHECKSUM = 0;
        public int SIZE = 0;
        public String TYPE = "attach";
    }

    public Text2EDMS()
    {       
    }

    /**
     * This method initializes the Text2EDMS environment and config file reader.
     *
     * @param   strDocbase      The EDMS docbase
     * @param   strScriptName   The name of the script utilized by the user
     * @param   strLogFile      Path to the logfile
     * @param   session         The object containing the user's session info.
     *
     * @return  True if the upload encountered no fatal errors.
     */
    public boolean init(String strDocbase, String strDocbaseLogic, String strScriptName, String strLogFile, IDfSession session) throws Exception
    {

        T2EConfig.initConfigFile(this.getClass().getResourceAsStream("/conf/text2edms.config"));
      
        setDocbase(strDocbase);
        setDocbaseLogic(strDocbaseLogic);
        setScriptName(strScriptName);
        setLogFile(strLogFile);
        setSession(session);
        setZipAttachments(T2EConfig.getZipByDefault(strDocbase));
        
        return true;
    } 

    /**
     * This method is the main driver of the program; it controls every aspect of
     * the attachment process. That process includes:
     *  <ul>
     *      <li>Initialize & call the Option handler (cmd line arg parser)
     *      <li>Retrieve & validate all cmd line input
     *      <li>Verify EDMS Calc Note existence if necessary
     *      <li>Loop through each passed attachment and:
     *      <ol>
     *          <li>determine the attachment's format
     *          <li>parse the attachment for attributes where necessary
     *          <li>store all attachment information in an Attachment object
     *          <li>zip the attachment if necessary
     *          <li>determine the checksum value of the attachment
     *          <li>format the attachment name
     *          <li>display attachment information OR attach the file
     *          <li>record success/failure of each attachment
     *      </ol>
     *  </ul>
     * @param   args    String array of the cmd line options entered by the user
     *
     * @return  True if no fatal errors occurred during the upload
     */
    public boolean run(String[] args) throws Exception
    {
        T2EOptionHandler t2eOptionHandler = new T2EOptionHandler();
        t2eOptionHandler.init();

        try
        {
            t2eOptionHandler.parseArguments(args);
        }
        catch(Exception e)
        {
            LogUtils.handleError("[ERROR] A fatal error has occurred: ", e);
            //
            // Or this can be changed to print the message 'invalid switch ______'
            //
            return false;
        }

        setDebugMode(t2eOptionHandler.getDebugMode());

        //
        // Check the debug log. If it was last modified today, keep it around.
        // Otherwise, delete it so that it will start from scratch. This will
        // prevent the log from growing too large while keeping it around long
        // enough to aid in troubleshooting.
        //
        if(getDebug())
        {
            File logFile = new File(Text2EDMS.getLogFile());
            if(logFile.exists())
            {
                String strLastMod = new SimpleDateFormat("MM/dd/yyyy").format(logFile.lastModified());
                String strToday = new SimpleDateFormat("MM/dd/yyyy").format(Calendar.getInstance().getTime());
                if(!strLastMod.equalsIgnoreCase(strToday))
                {
                    logFile.delete();
                }
            }
        }
        LogUtils.startLog();
        LogUtils.printDebug("DEBUGGING");
        LogUtils.printDebug("*** Init() Info ***\n");
        LogUtils.printDebug("SCRIPT: " + getScriptName());
        LogUtils.printDebug("DOCBASE: " + getDocbase());
        LogUtils.printDebug("DOCBASE LOGIC: " + getDocbaseLogic());
        LogUtils.printDebug("UNIX USER ID: " + System.getProperty("user.name"));
        LogUtils.printDebug("CURRENT DIR: " + System.getProperty("user.dir") + "\n");

        P_PARSE_ONLY = t2eOptionHandler.getParseOnly();
        F_USE_CL_NO_PARSE = t2eOptionHandler.getForceCMDValues();
        f_FORCE_CL_OVER_PARSE = t2eOptionHandler.getOverwriteParsedValues();
        C_GENERATE_CL_OPTS = t2eOptionHandler.getGenerateCMDOptionsFromFile();

        if(t2eOptionHandler.getPrintT2EVersion())
        {
            printT2EVersion();
        }

        if(F_USE_CL_NO_PARSE && f_FORCE_CL_OVER_PARSE)
        {
            LogUtils.handleError("[ERROR] A fatal error has occurred: ", new Exception("Invalid Switch: -F & -f are mutually exclusive flags"));
            return false;
        }
        if(P_PARSE_ONLY && C_GENERATE_CL_OPTS)
        {
            LogUtils.handleError("[ERROR] A fatal error has occurred: ", new Exception("Invalid Switch: -P & -C are mutually exclusive flags"));
            return false;
        }
        if(F_USE_CL_NO_PARSE && P_PARSE_ONLY)
        {
            LogUtils.handleError("[ERROR] A fatal error has occurred: ", new Exception("Invalid Switch: -F & -P are mutually exclusive flags"));
            return false;
        }
        //
        // If we're not zipping by default, check to see if the zip flag has been passed
        //
        if(!doZipAttachments())
        {
            setZipAttachments(t2eOptionHandler.getDoCompressFile());
        }

        //
        // Print some debug info if in debug mode
        //
        LogUtils.printDebug("*** Run() Info ***\n");
        LogUtils.printDebug("PARSE ONLY MODE: " + P_PARSE_ONLY);
        LogUtils.printDebug("CMD LINE GENERATION ONLY MODE: " + C_GENERATE_CL_OPTS);
        LogUtils.printDebug("CMD LINE ONLY MODE (no parsing): " + F_USE_CL_NO_PARSE);
        LogUtils.printDebug("FORCE CL OVER PARSED VALUES: " + f_FORCE_CL_OVER_PARSE);
        LogUtils.printDebug("ZIP ATTACHMENTS: " + doZipAttachments() + "\n");

        LogUtils.printDebug("*** Processing Command Line Args ***\n");

        List<Attachment> arrAttachments = new Vector<Attachment>();
        List<String> arrAttachNames = T2EConfig.toGenericList(t2eOptionHandler.getAttachNames());

        Hashtable<String,Object> hCLAttributes = new Hashtable<String,Object>();
        Hashtable<String,Object> hEsbuAttributes = new Hashtable<String,Object>();
        String strEsbuDocName = "";
        String strUserSubmittedFormat = "";

        //
        // Make sure there were some attachments passed!
        //
        if(arrAttachNames == null || arrAttachNames.size() <= 0)
        {
            LogUtils.handleError("[ERROR] A fatal error has occurred:", new Exception("No attachments passed"));
            return false;
        }

        try
        {
            hCLAttributes = t2eOptionHandler.getCommandLineArgumentValues("attach");
            hEsbuAttributes = t2eOptionHandler.getCommandLineArgumentValues("esbu");
        }
        catch(Exception e)
        {
            LogUtils.handleError("[ERROR] A fatal error has occurred: ", e);
            return false;
        }

        //
        // Log the passed options & values if we're in debug mode
        //
        if(getDebug())
        {
            Enumeration<String> keys = hCLAttributes.keys();
            while (keys.hasMoreElements())
            {
                String strKey = keys.nextElement();
                Object obj = hCLAttributes.get(strKey);
                String strOptionFlag = t2eOptionHandler.getOptionIdentifier(strKey);
                String strOutput = "";
                String strDelimiter = "";
                if(obj instanceof List)
                {
                    List<String> arrValues = T2EConfig.toGenericList((List)obj);
                    for (String strValue : arrValues)
                    {
                        if(strValue != null && strValue.length() > 0)
                        {
                            strOutput = strOutput + strDelimiter + "'" + strValue + "'";
                            strDelimiter = ", ";
                        }
                    }
                }
                else if (obj instanceof String)
                {
                    String strValue = (String)obj;
                    if(strValue != null && strValue.length() > 0)
                    {
                        strOutput = "'" + strValue + "'";
                    }
                }
                LogUtils.printDebug("Option: -" + strOptionFlag + "   Value: " + strOutput + "  Attachment Attribute: " + strKey);
            }
            keys = hEsbuAttributes.keys();
            while (keys.hasMoreElements())
            {
                String strKey = keys.nextElement();
                String strValue = (String)hEsbuAttributes.get(strKey); // hEsbuAttributes only contains strings
                String strOptionFlag = t2eOptionHandler.getOptionIdentifier(strKey);
                LogUtils.printDebug("Option: -" + strOptionFlag + "   Value: '" + strValue + "'  ESBU Attribute: " + strKey);
            }
        }

        if(hEsbuAttributes.containsKey("object_name"))
        {
            strEsbuDocName = (String)hEsbuAttributes.get("object_name");
        }
        else if(!P_PARSE_ONLY && !C_GENERATE_CL_OPTS)
        {
            LogUtils.printMsg("calc-note number is required");
            return false;
        }

        //
        // Determine if the user supplied file format is valid
        //
        if(t2eOptionHandler.hasUserSuppliedFormat())
        {
            strUserSubmittedFormat = (String)hCLAttributes.get("file_type");
            if(strUserSubmittedFormat != null && strUserSubmittedFormat.trim().length() > 0)
            {
                try
                {
                    LogUtils.printDebug("   Validating -G format: " + strUserSubmittedFormat);
                    if(isValidFormat(strUserSubmittedFormat))
                    {
                        LogUtils.printDebug("      Results: PASSED");
                    }
                    else
                    {
                        strUserSubmittedFormat = "";
                        LogUtils.printDebug("      Results: FAILED");
                        LogUtils.printMsg("[ERROR] A fatal error has occurred: Invalid format submitted. Passed Option: '-" +
                                t2eOptionHandler.getOptionIdentifier("file_type") +
                                " " + strUserSubmittedFormat + "'");
                        return false;
                    }
                }
                catch(Exception e)
                {
                    LogUtils.handleError("[ERROR] A fatal error has occurred: -G format validation failed.", e);
                    return false;
                }
            }
        }

        /*
         * Check to see if the esbu object exists
         * Verify the calcnote if:
         * - Not in parse only mode
         * - Not in generate cmd line options mode
         */
        if(!P_PARSE_ONLY && !C_GENERATE_CL_OPTS)
        {
            try
            {
                LogUtils.printMsg("Checking for unique calc-note");
                if(!isDocValid(hEsbuAttributes))
                {
                    return false;
                }
            }
            catch(Exception e)
            {
                LogUtils.handleError("[ERROR] An fatal error has occurred: calc-note validation failed.", e);
                return false;
            }
        }

        //
        // This is for NF's special needs
        //
        if(T2EConfig.needPostPend(getDocbaseLogic()) && f_FORCE_CL_OVER_PARSE)
        {
            LogUtils.printDebug("   Postpending attributes");
            postPendAttributes(hCLAttributes);
        }

        //
        // Initialize new banners for the current docbase & attachment
        //
        LogUtils.printDebug("*** Banner Initialization ***");
        
        int intNumBanners = T2EConfig.getBannerCount();
        List<T2EBanner> arrBanners = new Vector<T2EBanner>();

        if(!F_USE_CL_NO_PARSE)
        {   for(int x=1; x<=intNumBanners; x++)
            {
                List<String> arrBannerDocbases = T2EConfig.getBannerDocbase(x);
                List<String> strBannerDocbaseLogic = T2EConfig.getBannerDocbaseLogic(x);
                if(arrBannerDocbases.contains(getDocbaseLogic()) && strBannerDocbaseLogic.contains(getDocbaseLogic()))
                {
                    T2EBanner t2eBanner = (T2EBanner)Class.forName(T2EConfig.getBannerClassPath(x)).newInstance();
                    t2eBanner.init(x, getDocbase());
                    LogUtils.printDebug("   " + t2eBanner.getName() + " initiated successfully");
                    arrBanners.add(t2eBanner);
                }
            }
        }
        else
        {
            LogUtils.printDebug("   No banners initialized: -F option encountered");
        }

        //
        // Loop through each attachment file
        //
        LogUtils.printDebug("*** Attachments ***\n");
        LogUtils.printDebug("   Total Attachments: " + arrAttachNames.size());
        setTotalAttachments(arrAttachNames.size());

        for(String strAttachName : arrAttachNames)
        {
            if(!F_USE_CL_NO_PARSE)
            {
                LogUtils.printDebug("      Resetting banners:");
                for(T2EBanner t2eBanner : arrBanners)
                {
                    t2eBanner.reset();
                }
                LogUtils.printDebug("         Complete");
            }
            if(!P_PARSE_ONLY && !C_GENERATE_CL_OPTS)
            {
                LogUtils.printMsg("Processing calc-note attachment: " + strAttachName);
            }
            Hashtable<String,Object> hParsedAttributes = new Hashtable<String,Object>();
            hParsedAttributes.clear();
            File fileAttach = new File(strAttachName);
            if(!fileAttach.exists() || !fileAttach.canRead() || fileAttach.isDirectory())
            {
               LogUtils.printMsg("[SKIP] File " + strAttachName + " cannot be opened, skipping " + fileAttach.getPath());
               incrementFailure();
               continue;
            }

            Attachment t2eAttachment = new Attachment();
            t2eAttachment.PATH = fileAttach.getAbsolutePath();
            t2eAttachment.FORMAT = T2EConfig.getDefaultContentType(getDocbase());

                
            try
            {
                if(!P_PARSE_ONLY && !C_GENERATE_CL_OPTS)
                {
                    strEsbuDocName = getEDMSDocument().getObjectName().trim();
                }

                //
                // Look up file parsing exception list
                //
                t2eAttachment.FORMAT = getContentFormat(fileAttach);
                if(!F_USE_CL_NO_PARSE)
                {
                    LogUtils.printDebug("   Testing file format: " + t2eAttachment.FORMAT);
                    try
                    {
                        if(!T2EConfig.getNonParseableFormats().contains(t2eAttachment.FORMAT))
                        {
                            //
                            // Parse the file
                            //
                            LogUtils.printDebug("      Parsing the file: " + fileAttach.getAbsolutePath());
                            hParsedAttributes.putAll(parseAttachmentFile(fileAttach, arrBanners));
                            LogUtils.printDebug("         Parsing complete");
                            // Done with banner parsing
                        }
                        else
                        {
                            LogUtils.printDebug("      Not parsing - exempt file format: " + t2eAttachment.FORMAT);
                        }
                    }
                    catch(Exception e)
                    {
                        LogUtils.handleError("[SKIP] Error parsing the file '" + fileAttach.getPath() + "':", e);
                        incrementFailure();
                        continue;
                    }
                }

                //
                // We can assume that if file_type exists & isn't null that it is valid because
                // of the validation steps taken earlier.
                //
                if(t2eOptionHandler.hasUserSuppliedFormat())
                {
                    strUserSubmittedFormat = (String)hCLAttributes.get("file_type");
                    if(strUserSubmittedFormat != null && strUserSubmittedFormat.trim().length() > 0)
                    {
                        t2eAttachment.FORMAT = strUserSubmittedFormat.toLowerCase().trim();
                        LogUtils.printDebug("      Setting format to user supplied value: " + t2eAttachment.FORMAT);
                    }
                }
                else
                {
                    LogUtils.printDebug("      Setting format to computed value: " + t2eAttachment.FORMAT);
                }

                //
                // Zip the attachment and then determine the checksum value. This is done here because
                // it is only needed if the attachment is going to be
                // imported...and this process needs a try/catch.
                //
                // type to_signed as dmadmin to compare this result
                //
                // Don't zip it if it is already zipped
                //
                LogUtils.printDebug("   Zipping attachment:");
                if(doZipAttachments())
                {
                    LogUtils.printDebug("      Allowed");
                    LogUtils.printDebug("         Testing Format");
                    if(!T2EConfig.getNonZippableFormats(getDocbase()).contains(t2eAttachment.FORMAT))
                    {
                        LogUtils.printDebug("            PASS");
                        LogUtils.printMsg("     File will be compressed");
                        if(!P_PARSE_ONLY && !C_GENERATE_CL_OPTS)
                        {
                            File fileZippedAttachment = zipAttachment(t2eAttachment);
                            t2eAttachment.PATH = fileZippedAttachment.getCanonicalPath();
                        }
                        else
                        {
                            t2eAttachment.PATH = t2eAttachment.PATH + ".gz";
                        }
                        t2eAttachment.FORMAT = T2EConfig.getZipFormat(getDocbase());

                        LogUtils.printDebug("         " + T2EConfig.getZipFormat(getDocbase()) + " compression completed");

                    }
                    else
                    {
                        LogUtils.printDebug("            FAIL");
                        LogUtils.printMsg("     File will NOT be compressed");
                    }
                }
                else
                {
                    if(P_PARSE_ONLY)
                    {
                        LogUtils.printDebug("      Denied - Parse Only (-P) mode");
                    }
                    else if(C_GENERATE_CL_OPTS)
                    {
                        LogUtils.printDebug("      Denied - Command Line Generation (-C) mode");
                    }
                    else
                    {
                        LogUtils.printDebug("      Denied - No zip option (-z) detected");
                    }
                }
            }
            catch (Exception e)
            {
                LogUtils.handleError("[SKIP] An error has occurred: ", e);
                incrementFailure();
                continue;
            }

            //
            // Overwrite the parsed values with cmd line values
            //
            if(F_USE_CL_NO_PARSE)
            {
                t2eAttachment.ATTRIBUTES.putAll(hCLAttributes);
            }
            else
            {
                if(f_FORCE_CL_OVER_PARSE)
                {
                    //hParsedAttributes.putAll(hCLAttributes);
                    t2eAttachment.ATTRIBUTES.putAll(hParsedAttributes);
                    t2eAttachment.ATTRIBUTES.putAll(hCLAttributes);
                }
                else
                {
                    // Overwrite the cmd line values with parsed values
                    //hCLAttributes.putAll(hParsedAttributes);
                    t2eAttachment.ATTRIBUTES.putAll(hCLAttributes);
                    t2eAttachment.ATTRIBUTES.putAll(hParsedAttributes);
                }
            }
            

            //
            // Format the name & determine the content format
            //
            try
            {
                LogUtils.printDebug("   Formatting attachment name:" );
                String strFormattedName = formatAttachmentName(t2eAttachment, strEsbuDocName);
                t2eAttachment.ATTRIBUTES.put("esbu_object_name", strEsbuDocName);
                t2eAttachment.ATTRIBUTES.put("object_name", strFormattedName);
                t2eAttachment.NAME = strFormattedName;
                LogUtils.printDebug("      Completed" );
                LogUtils.printDebug("Attachment pre-processing completed" );
                arrAttachments.add(t2eAttachment);
            }
            catch(Exception e)
            {
                LogUtils.handleError("[SKIP] An error has occurred: ", e );
                incrementFailure();
                continue;
            }
        }

        //
        // Upload or display (depending on mode) each successfully processed attachment
        //
        for(Attachment t2eAttachment : arrAttachments)
        {
            try
            {
                if(P_PARSE_ONLY || C_GENERATE_CL_OPTS)
                {
                    LogUtils.printMsg(displayAttachmentAttributes(t2eAttachment, t2eOptionHandler, hEsbuAttributes));
                }
                else
                {
                    LogUtils.printDebug("   Uploading attachment " + t2eAttachment.NAME);
                    LogUtils.printDebug("      Calculating Checksum: ");
                    t2eAttachment.CHECKSUM = determineChecksum(t2eAttachment.PATH);
                    LogUtils.printDebug("         Value:" + t2eAttachment.CHECKSUM);
                    
                    LogUtils.printDebug("      Calculating File size: ");
                    t2eAttachment.SIZE = determineFileSize(t2eAttachment.PATH);
                    LogUtils.printDebug("         Value:" + t2eAttachment.SIZE);
                    //
                    // Upload the attachment via a tansaction. This makes it
                    // easier to clean up if anything goes wrong.
                    //
                    SESSION.beginTrans();                
                    uploadAttachment(t2eAttachment);
                    SESSION.commitTrans();
                    incrementSuccess();
                    LogUtils.printMsg("      " + t2eAttachment.ATTRIBUTES.get("object_name") + " saved as an attachment to " + strEsbuDocName);
                }
            }
            catch (Exception e)
            {
                LogUtils.handleError("[SKIP] An error has occurred: ", e);
                incrementFailure();
                try{ SESSION.abortTrans(); } catch (DfException ex) {}
                continue;
            }
        }
        
       
        return true;
    }
    
    /**
     * This method determines whether the user submitted format is valid. It does 
     * so by querying the dm_format table for the lowercase value.
     *
     * @param strUserSubmittedFormat    The user specified format (-G option)
     *
     * @return True if the format is valid.
     */
    private boolean isValidFormat(String strUserSubmittedFormat) throws Exception
    {
        boolean boolIsValid = false;
        IDfCollection col = null;
        IDfQuery dfQuery = new DfQuery();
        int intNumFormats = 0;

        //
        // Query for the proper content format.
        //
        dfQuery.setDQL("SELECT count(*) as num_formats " +
                       "FROM dm_format " +
                       "WHERE name='" + strUserSubmittedFormat.toLowerCase().trim() + "'");
        try
        {
            //
            // Execute the query
            //
            col = dfQuery.execute(SESSION,IDfQuery.DF_READ_QUERY);
            col.next();
            intNumFormats = col.getInt("num_formats");
            if (intNumFormats > 0)
            {
                boolIsValid = true;
            }
            else
            {
                boolIsValid = false;
            }
        }
        catch(Exception e)
        {
            throw e;
        }
        finally
        {
            try
            {
                if (col != null && col.getState() != IDfCollection.DF_CLOSED_STATE)
                {
                     col.close();
                }
            } catch (DfException e) {}
        }
        return boolIsValid;
    }

    /**
     * This method validates the EDMS doc (esbu obj) information passed by the
     * user. The information is valid if the doc:
     *      -exists
     *      -is not archived
     *      -is unique
     *      -is writeable by the user
     *
     * @param   hEsbuAttributes     Hashtable containing the esbu doc info
     *
     * @return  True if the document exists and is valid
     */
    private boolean isDocValid(Hashtable<String,Object> hEsbuAttributes) throws Exception
    {
        boolean boolIsValid = true;

        String strEsbuName = (String)hEsbuAttributes.get("object_name");
        String strEsbuRev = (String)hEsbuAttributes.get("esbu_revision");
        String strEsbuSheet = (String)hEsbuAttributes.get("esbu_sheet");
        
        try
        {
            if(strEsbuName == null)
            {
                LogUtils.printMsg("calc-note number is required");
                return false;
            }
            String strQualification = "esbu WHERE UPPER(object_name) = '" + strEsbuName.toUpperCase().replaceAll("'", "''") + "' ";
            if (strEsbuRev != null)
            {
            strQualification = strQualification + "AND UPPER(esbu_revision) = '" + strEsbuRev.toUpperCase().replaceAll("'", "''") + "' ";
            }
            if (strEsbuSheet != null)
            {
            strQualification = strQualification + "AND UPPER(esbu_sheet) = '" + strEsbuSheet.toUpperCase().replaceAll("'", "''") + "'";
            }

            if (!isDocUnique(strQualification))
            {
                boolIsValid = false;
            }
            else
            {
                //
                // Check everything else
                //  -is archived
                //  -is checked out
                //  -have permissions
                //
                setEDMSDocument(strQualification);
                IDfSysObject edmsDoc = getEDMSDocument();

                //
                // Replace the hash's object_name with the EDMS formatted name.
                // This eliminates the potential for a poorly formatted attachment name.
                //
                hEsbuAttributes.put("object_name", edmsDoc.getObjectName().trim());

                if(edmsDoc.isCheckedOut())
                {
                    LogUtils.printMsg("ESBU Document is checked out.\nPlease Check it in.");
                    boolIsValid = false;
                }
                else if(edmsDoc.getStorageType().toLowerCase().startsWith("archive"))
                {
                    LogUtils.printMsg("ESBU Document is already archived.  Cannot make any new attachments.");
                    boolIsValid = false;
                }
                else if(edmsDoc.getPermit() < IDfACL.DF_PERMIT_WRITE)
                {
                    LogUtils.printMsg("Insufficient privileges to the ESBU Document.\n You must have at least write permission.");
                    boolIsValid = false;
                }
            }
        }
        catch(Exception e)
        {
            boolIsValid = false;
            throw e;
        }      
        return boolIsValid;
    }
    /**
     * This method tests the edms document's uniqueness.
     *
     * @param   strQualification    The 'where' clause of the uniqueness query.
     *
     * @return  True if the document is unique.
     */
    private boolean isDocUnique(String strQualification) throws Exception
    {
        IDfQuery query = null;
        IDfCollection col = null;
        int intNumDocs;
        boolean boolIsUnique = false;
                 
        //
        // Check uniqueness
        //
        String strQuery = "SELECT COUNT(*) AS num_docs FROM " + strQualification;

        try
        {
            query = new DfQuery();
            query.setDQL(strQuery);
            LogUtils.printDebug("   Executing query: " + strQuery);
            col = query.execute(SESSION, IDfQuery.DF_READ_QUERY);
            col.next();
            intNumDocs = col.getInt("num_docs");
            if (intNumDocs == 1)
            {
                boolIsUnique = true;
            }
            else if ( intNumDocs == 0)
            {
                LogUtils.printMsg("Could not find calc-note.  Please check the calc-note number, revision, and/or sheet number");
            }
            else
            {
                LogUtils.printMsg("Calc-note is not unique.  " + intNumDocs + " matches were found.\nPlease enter revision and/or sheet number");
            }
        }
        catch (Exception e)
        {                        
            throw e;
        }
        finally
        {
            if (col != null && col.getState() != IDfCollection.DF_CLOSED_STATE)
            {
                try { col.close(); } catch (DfException e) {}
            }
        }
        return boolIsUnique;
    }

    /**
     * This method determines the attachment's content type based on the document's
     * extension. If no extension is found or the extension does not have a
     * related dm_format then a 'binary' test is performed to determine if the
     * attachment is binary.
     *
     * @param fileAttach    The attachment file
     *
     * @return The string representation of the determined format.
     */
    private String getContentFormat(File fileAttach) throws Exception
    {
        String strContentType = T2EConfig.getDefaultContentType(getDocbase());
        String strFileName = fileAttach.getName();
        boolean boolDoBinaryTest = false;
        IDfCollection col = null;
        IDfQuery dfQuery = new DfQuery();
        int index = strFileName.lastIndexOf(".");
        String strFileExtension = strFileName.substring(index+1,strFileName.length());
        LogUtils.printDebug("   Determining file format:");
        if(index > -1 && (strFileExtension != null || !strFileExtension.equalsIgnoreCase("")))
        {
            strFileExtension = strFileExtension.toLowerCase();
            
            //
            // Check the config file:
            //
            Hashtable<String,String> hFormatMappings = T2EConfig.getForcedFormatMap();
            if(hFormatMappings.containsKey(strFileExtension))
            {
                strContentType = hFormatMappings.get(strFileExtension);
            }
            else
            {
                //
                // Query for the proper content format.
                //
                dfQuery.setDQL("SELECT name " +
                               "FROM dm_format " +
                               "WHERE dos_extension='" + strFileExtension + "'");
                try
                {
                    //
                    // Execute the query
                    //
                    LogUtils.printDebug("      Query: " + dfQuery.getDQL());
                    col = dfQuery.execute(SESSION,IDfQuery.DF_READ_QUERY);
                    if(col.next())
                    {
                        //
                        // Return the content type.
                        //
                        strContentType = col.getString("name");
                        col.close();
                        LogUtils.printDebug("   Found format: '" + strContentType + "'");
                    }
                    else
                    {
                        LogUtils.printDebug("No dm_format found. Performing binary test:");
                        boolDoBinaryTest = true;
                    }
                }
                catch(Exception ex)
                {
                    LogUtils.printMsg("    Query failed: " + ex.getMessage());
                }
                finally
                {
                    try
                    {
                        if (col != null && col.getState() != IDfCollection.DF_CLOSED_STATE)
                        {
                             col.close();
                        }
                    } catch (DfException e) {}
                }
            }
        }
        else
        {
            LogUtils.printDebug("      No extension found. Performing binary test:");
            boolDoBinaryTest = true;
        }
        //
        // If no extension exists or no dm_format was found, test to see if
        // the object is a Binary. If it is, return 'binary', otherwise return 'text'
        //
        if(boolDoBinaryTest)
        {
            if(isBinary(fileAttach))
            {
                LogUtils.printDebug("         is binary");
                strContentType = "binary";
            }
            else
            {
                LogUtils.printDebug("         NOT binary.");

            }
        }
        LogUtils.printDebug("      Determined file format: " + strContentType);
        return strContentType;
    }

    /**
     * This method performs the binary test on the file. The test loops through
     * the first 2048 characters of a file and tests each character for 'readability'.
     * If greater than 30% of the characters are not human readable, then the
     * file is considered binary.
     *
     * @param fileAttach    The attachment file
     *
     * @return True if the file is binary.
     */
    private boolean isBinary(File fileAttach)
    {
        boolean boolIsBinary = false;
        BufferedReader br = null;

        try
        {
            br = new BufferedReader(new FileReader(fileAttach));
            char [] arrChars = new char[2048]; //do a peek
            int dblNumNonPrintables = 0;
            int intNumChars = br.read(arrChars,0,2048);
            br.close();

            LogUtils.printDebug("      Num chars read in: " + intNumChars);
            LogUtils.printDebug("      array size: " + arrChars.length);
            for(int index=0; index<intNumChars; index++)
            {
                char chrTest = arrChars[index];
                int x = (int)chrTest;
                index++;
                if(x == 0)
                {
                    LogUtils.printDebug("      Zero character encountered. File defaulted to binary");
                    return true;
                }
                else if(x < 32 || x > 127)
                {
                    dblNumNonPrintables++;                                          //Close the file input somewhere
                }
            }
            double pb = (double)dblNumNonPrintables/intNumChars;
            LogUtils.printDebug("      Determined Probability: " + pb + " ---(larger than .3 is probably binary)");
            if(pb > 0.3)
            {
                boolIsBinary = true;                
            }
        }
        catch(Exception e)
        {
            boolIsBinary = false;
            try 
            { 
                br.close();
                LogUtils.handleError("[ERROR] The following error has been encountered:", e);
            } 
            catch (IOException ex) {}
        }
        
        return boolIsBinary;
    }

    /**
     * This method determines the checksum value for the given attachment.
     *
     * @param   strPath     The path to the attachment
     *
     * @return Returns the integer (signed) representation of the checksum value.
     */
    private int determineChecksum(String strPath) throws Exception
    {
        int intChecksum = 0;
        AbstractChecksum abChecksum = JacksumAPI.getChecksumInstance("cksum");
        
        abChecksum.readFile(strPath);
        Long longCksum = abChecksum.getValue();
        BigInteger bigInteger = new BigInteger(longCksum.toString());
        intChecksum = bigInteger.intValue();

        return intChecksum;
    }
    
    /**
     * This method determines the file size as a signed integer.
     *
     * @param   strPath     The path to the attachment
     *
     * @return Returns the integer (signed) representation of the file's size.
     */
    private int determineFileSize(String strPath) throws Exception
    {
        int intSize = 0;
        File tempFile = new File(strPath);
        Long longSize = tempFile.length();
        BigInteger bigInteger = new BigInteger(longSize.toString());
        intSize = bigInteger.intValue();

        return intSize;
    }    

    /**
     * This method parses the attachment file. The first recognized banner will
     * be used to parse the attachment's properties, followed by a secondary
     * 'child' banner which is specified by the primary. Not all primary banners
     * have secondaries. The general flow of this function is:
     *      <ui>
     *      <li>Loop through each line of the file
     *      <li>Each line will be passed to each banner parser until a primary is identified
     *      <li>The primary parser will parse its associated attributes
     *      <li>Once complete, a secondary parser will be activated if specified
     *      <li>Each banner will perform processing on their parsed values
     *      <li>A hashtable of the combined values will be returned
     *      </ui>
     *
     * @param   fileAttach      The attachment to be parsed
     * @param   arrBanners      The list of primary banner objects
     *
     * @return A hashtable of the combined parsed & processed values
     */
    private Hashtable<String,Object> parseAttachmentFile(File fileAttach, List<T2EBanner> arrBanners) throws Exception
    {  
        boolean boolBannerFound = false;
        boolean boolHasNextBanner = false;
        boolean boolProcessPrimaryBanner = false;
        boolean boolProcessSecondaryBanner = false;
        boolean boolBeginPrimaryParsing = false;
        T2EBanner t2ePrimaryBanner = null;
        T2EBanner t2eSecondaryBanner = null;
        int intSecondaryBannerNumber = 0; 
        String strLine = "";
        Hashtable<String,Object> hPrimaryBannerParsedAttributes = null;
        Hashtable<String,Object> hSecondaryBannerParsedAttributes = null;
        Hashtable<String,Object>hCompleteParsedAttributes = new Hashtable<String,Object>();
        
        //
        // Open attachment for reading
        //        
        BufferedReader reader = new BufferedReader(new FileReader(fileAttach));
        
        //
        //While !EOF
        //     Pass the line to each bannerParser
        //     Each parser will return true/false it finds the initial regex
        //     First one to return true will be the parser we use.
        //          //Flag that a banner has been found
        //          //Parse the appropriate banner until completion
        //          //Get the parsed attributes
        //          //Check to see if there are any child banners
        //     Process any child banners
        //WEND
        //
        LogUtils.printDebug("         Searching for banner match:");
        while ((strLine = reader.readLine()) != null)
        {
            if(!boolBannerFound)
            {
                for(T2EBanner t2eTempBanner : arrBanners)
                {
                    //
                    // Test the line for against each banner
                    //
                  //  LogUtils.printDebug("TESTING");
                    if(t2eTempBanner.testLine(strLine))
                    {
                        boolBannerFound = true;
                        t2ePrimaryBanner = t2eTempBanner;
                        boolProcessPrimaryBanner = true;
                        LogUtils.printDebug("            Primary Banner found! Name: " + t2ePrimaryBanner.getName());

                        //
                        // If the banner is only one line, like the ccheck banner,
                        // then we'll need to parse that line right now because
                        // the banner identification line IS the entire banner.
                        // Not parsing the banner right now would essentially
                        // cause the banner to be skipped.
                        //
                        
                        if(t2ePrimaryBanner.getSize() == 1)
                        {
                            boolBeginPrimaryParsing = true;
                        }
                        //  LogUtils.printDebug("BROKE OUT");
                        break;
                    }
                }
            }
            
            if(boolProcessPrimaryBanner)
            {
                //
                // We're in this section because we've found a banner.
                // Check to see if the banner has finished processing
                //
                if(!t2ePrimaryBanner.hasFinished() && boolBeginPrimaryParsing)
                {   
                    t2ePrimaryBanner.parseLine(strLine);
                }
                
                //
                // Check to see if the banner has finished now, that way we can 
                // properly process the banner if it happened to finish on the 
                // last line contained in the file or if it was a one-liner.
                //
                if(t2ePrimaryBanner.hasFinished())
                {      
                    LogUtils.printDebug("      Primary banner parsing complete.");
                                      
                    LogUtils.printDebug("   *** Secondary Banner Processing ***");
                    boolHasNextBanner = t2ePrimaryBanner.hasSecondaryBanner();
                    if(boolHasNextBanner)
                    {
                        intSecondaryBannerNumber = t2ePrimaryBanner.getSecondaryBannerNumber();
                        if(intSecondaryBannerNumber > 0)
                        {
                            t2eSecondaryBanner = (T2EBanner)Class.forName(T2EConfig.getBannerClassPath(intSecondaryBannerNumber)).newInstance();
                            t2eSecondaryBanner.init(intSecondaryBannerNumber, getDocbase());
                            boolProcessSecondaryBanner = true;
                            boolProcessPrimaryBanner = false;
                            LogUtils.printDebug("      Secondary Banner init() complete.\n");
                        }
                    }
                    else
                    {
                        //Log the lack of child banner
                        // & break - so we don't keep reading through the file
                        LogUtils.printDebug("         No secondary banner found.\n");
                        break;
                    }
                }
                boolBeginPrimaryParsing = true;
            }
            
            if(boolProcessSecondaryBanner)
            {                
                if(t2eSecondaryBanner != null)
                {
                    if(!t2eSecondaryBanner.hasFinished())
                    {
                        if(!t2eSecondaryBanner.isSelected())
                        {
                            t2eSecondaryBanner.testLine(strLine);
                            if(t2eSecondaryBanner.getSize() == 1)
                            {
                                t2eSecondaryBanner.parseLine(strLine);
                            }
                        }
                        else
                        {
                            t2eSecondaryBanner.parseLine(strLine);
                        }
                    }
                    else
                    {
                        //
                        //Process the secondary banner's parsed attributes
                        //
                        LogUtils.printDebug("      Secondary banner parsing complete.");
                        
                        break;
                    }
                }
                else
                {
                    LogUtils.printDebug("      Secondary banner is null. Breaking.");
                    break;
                }
            }   
        }
        reader.close();

        //
        // Process each banner's attributes now that the reading portion has completed.
        //
        if(t2ePrimaryBanner != null)
        {
            LogUtils.printDebug("      Processing primary's banners parsed attribtues:");
            t2ePrimaryBanner.processParsedAttributes();
            hPrimaryBannerParsedAttributes = t2ePrimaryBanner.getParsedAttributes();
            LogUtils.printDebug("         Complete");
            LogUtils.printDebug("      Processing secondary's parsed attributes:");

            if(t2ePrimaryBanner.hasFinished())
            {
                if(t2eSecondaryBanner != null && t2eSecondaryBanner.isSelected())
                {
                    t2eSecondaryBanner.processParsedAttributes();
                    //
                    // Perform additional processing based on the primary banners attributes
                    //
                    LogUtils.printDebug("         Proccessing secondary's parsed attributes against the primary's:");
                    t2eSecondaryBanner.processParsedAttributes(hPrimaryBannerParsedAttributes);
                    //
                    //Done
                    //
                    hSecondaryBannerParsedAttributes = t2eSecondaryBanner.getParsedAttributes();
                    LogUtils.printDebug("         Complete");
                }
                else
                {
                    LogUtils.printDebug("         No secondary banner encountered");
                }
            }
            else
            {
                LogUtils.printDebug("         No secondary banner initiated - primary didn't finish");
            }
        }
        else
        {
            LogUtils.printDebug("      No banners encountered");
        }

        //
        // Add both parsed hashtables to the completed hashtable.
        // Do not overwrite the primary hashtable's info with the secondary's.
        // Secondary banners are used to suppliment primary banners.
        //
        if(hSecondaryBannerParsedAttributes != null)
        {
            LogUtils.printDebug("         Adding secondary banner's parsed attributes");
            hCompleteParsedAttributes.putAll(hSecondaryBannerParsedAttributes);
        }
        if(hPrimaryBannerParsedAttributes != null)
        {
            LogUtils.printDebug("         Adding primary banner's parsed attributes");
            hCompleteParsedAttributes.putAll(hPrimaryBannerParsedAttributes);
        }

        return hCompleteParsedAttributes;
    }   

    /**
     * This function performs the actual upload of the attachment to EDMS. It will:
     *      -Create an EDMS attach object
     *      -Set the Attributes that were determined via parsing & command line
     *      -Update the esbu object to include the new attachtment in its attributes
     *      -Set the attachment's content (e.g. upload the file)
     *      -Set the permissions, locations, and other 'system' attributes for the attachment
     *      -Save the changes to the attach & esbu objects
     *
     * @param   t2eAttachment   The attachment to be uploaded
     *
     */
    private void uploadAttachment(Attachment t2eAttachment) throws Exception 
    {
        IDfSysObject edmsDoc = getEDMSDocument();        
        //
        // Create the new attach object
        //
        IDfSysObject edmsAttachment = (IDfSysObject) SESSION.newObject(t2eAttachment.TYPE);

        //
        // Remove the file_type as an attribute as it is only for display purposes
        //
        t2eAttachment.ATTRIBUTES.remove("file_type");
        //
        // Set the attributes
        //
        Enumeration<String> keys = t2eAttachment.ATTRIBUTES.keys();
        while (keys.hasMoreElements())
        {
            String strAttribute = keys.nextElement();
            Object objValue = t2eAttachment.ATTRIBUTES.get(strAttribute);
            if (objValue instanceof String)
            {
                String strValue = (String)objValue;
                LogUtils.printDebug("      Setting " + strAttribute + " to '" + strValue + "'");
                edmsAttachment.setString(strAttribute, strValue);
            }
            else if (objValue instanceof List)
            {
                List<String> arrValues = T2EConfig.toGenericList((List)objValue);
                for (String strValue : arrValues)
                {
                    LogUtils.printDebug("      Setting " + strAttribute + " to '" + strValue + "'");
                    edmsAttachment.appendString(strAttribute, strValue);
                }
            }
        }
             
        String strEsbuRev = edmsDoc.getString("esbu_revision");
        String strEsbuSheet = edmsDoc.getString("esbu_sheet");

        if (strEsbuRev != null && strEsbuRev.length() > 0)
        {
            LogUtils.printDebug("      Setting esbu_revision to '" + strEsbuRev + "'");
            edmsAttachment.setString("esbu_revision", strEsbuRev);
        }
        if (strEsbuSheet != null && strEsbuSheet.length() > 0)
        {
            LogUtils.printDebug("      Setting esbu_sheet to '" + strEsbuSheet + "'");
            edmsAttachment.setString("esbu_sheet", strEsbuSheet);
        }

        LogUtils.printDebug("      Setting esbu_object to '" + edmsDoc.getObjectId().toString() + "'");
        edmsAttachment.setString("esbu_object", edmsDoc.getObjectId().toString());

        LogUtils.printDebug("      Setting att_checksum to '" + t2eAttachment.CHECKSUM + "'");
        edmsAttachment.setInt("att_checksum", t2eAttachment.CHECKSUM);

        LogUtils.printDebug("      Setting att_size to '" + t2eAttachment.SIZE + "'");
        edmsAttachment.setInt("att_size", t2eAttachment.SIZE);      

        LogUtils.printDebug("      Setting Permissions:");
        edmsAttachment.setACLName(T2EConfig.getACLName(getDocbase()));
        edmsAttachment.setACLDomain(T2EConfig.getACLDomain(getDocbase()));
        edmsAttachment.link(T2EConfig.getAttachmentLinkDir(getDocbase()));
        edmsAttachment.setOwnerName(T2EConfig.getOwnerName(getDocbase()));
        LogUtils.printDebug("         Done");

        //
        // Set the content type & move the content
        //
        LogUtils.printDebug("      Setting content:");
      //  edmsAttachment.setContentType(t2eAttachment.FORMAT);
        LogUtils.printDebug("         Type: '" + t2eAttachment.FORMAT + "'");
        LogUtils.printDebug("         Path: '" + t2eAttachment.PATH + "'");
        edmsAttachment.setFileEx(t2eAttachment.PATH, t2eAttachment.FORMAT, 0, null);
        LogUtils.printDebug("         Done");

        LogUtils.printDebug("      Saving attachment:");
        edmsAttachment.save();
        LogUtils.printDebug("         Success!");
        
        LogUtils.printDebug("      Updating esbu document:");
        
        edmsDoc.appendString("att_object_name", edmsAttachment.getObjectName() + " " + edmsAttachment.getObjectId().toString());
        LogUtils.printDebug("         Setting att_opject_name to: " + edmsAttachment.getObjectName() + " " + edmsAttachment.getObjectId().toString());
        LogUtils.printDebug("         Saving changes:");
        edmsDoc.save(); 
        LogUtils.printDebug("            Success!");
    }

    /**
     * This function performs the java gzip action on an attachment and will
     * delete the original upon successful completion.
     *
     * @param   t2eAttachment   The attachment to be zipped.
     *
     * @return  The zipped attachment.
     */
    private File zipAttachment(Attachment t2eAttachment) throws Exception
    {
        // Create the GZIP output stream
        GZIPOutputStream out = null;
        FileInputStream in = null;
        File zipFile = null;
        File inputFile = null;
        File directory = null;
        try
        { 
            inputFile = new File(t2eAttachment.PATH);
            directory = inputFile.getParentFile();
            if(directory != null && directory.canWrite())
            {
                zipFile = new File(t2eAttachment.PATH + ".gz");
                out = new GZIPWithHeaderOutputStream(inputFile);

                // Open the input file
                in = new FileInputStream(inputFile);

                // Transfer bytes from the input file to the GZIP output stream
                byte[] buf = new byte[2048];
                int len;
                while ((len = in.read(buf)) > 0) 
                {
                    out.write(buf, 0, len);
                }
                in.close();

                // Complete the GZIP file
                out.flush();
                out.finish();
                out.close();
                
                zipFile.setLastModified(inputFile.lastModified());
                inputFile.delete();
            }
            else
            {
                throw new Exception("No write permissions for directory '" + directory.getPath() + "'");
            }
            return zipFile;
        }
        catch(Exception e)
        {
            LogUtils.printDebug("[ERROR]Error during zip proccessing");
            throw e;
        }
        finally
        {
            if(out != null)
            {
                out.close();
            }
            if(in != null)
            {
                in.close();
            }
        }
    }

    /**
     * This class extends the GZIPOutputStream class to enable the program to
     * enter a proper header for the gzip file. Java GZIP does not include the
     * original file name or the original modified date. This causes issues if
     * the actual gzip file gets renamed. While this does not affect the integrity
     * of the compressed file, adding the original file name & date provides for
     * an better end user experience as the gzip will always decompress the file
     * to the proper name.
     */
    private class GZIPWithHeaderOutputStream extends GZIPOutputStream
    {
        /**
         * This constructor calls the super constructor with the intention of not
         * utilizing the modified output stream. Instead, it creates another
         * output stream directly from the file. This allows the program to utilize
         * the functionality of the GZIPOutputStream class while discarding the
         * faulty (incomplete) header information and providing its own.
         *
         * @param inputFile The input file to zip.
         * @throws IOException
         */
        public GZIPWithHeaderOutputStream(File inputFile) throws IOException
        {
            super(new ByteArrayOutputStream());
            FileOutputStream fout = new FileOutputStream(inputFile.getPath() + ".gz");
            int intModTime = (int)(inputFile.lastModified() / 1000L);

            //
            // Swap the stream with our unmodified outputstream
            //
            out = fout;

            //
            // Build the custom header - include last modified date
            //
            byte[] header =
            {
                (byte)GZIPInputStream.GZIP_MAGIC,          // ID1
                (byte)(GZIPInputStream.GZIP_MAGIC >> 8),   // ID2
                (byte)Deflater.DEFLATED,                   // CM
                (byte)8,                                   // FLG (FNAME=1)
                (byte)intModTime,                          // MTIME1
                (byte)(intModTime >> 8),                   // MTIME2
                (byte)(intModTime >> 16),                  // MTIME3
                (byte)(intModTime >> 24),                  // MTIME4
                (byte)0,                                   // XFL
                (byte)0                                    // OS
            };

            //
            // write the header & add the filename. Terminate with a zero byte.
            //
            out.write(header);
            out.write(inputFile.getName().getBytes("ISO-8859-1"));
            out.write((byte)0);

            //
            // No idea what this does but do it.
            //
            crc.reset();
        }
    }

    /**
     * This function formats the attachment's EDMS object name by replacing special
     * characters with underscores and combining the current name, a unique 
     * identifier, and the name of the EDMS esbu document. The format will look
     * like this: current_attach_name.txt_<some number>_esbu_calc_name.
     * 
     * The unique identifier will be either be parsed out of the attachment or 
     * a random & unique number. The potential parse values are the dql job id, the 
     * execution id, or the process id. The random & unique number is not 
     * random but is actually generated via the UNIX system time in seconds. A 
     * one second sleep is performed between each attachment to provide unique 
     * times for each attachment.
     *
     * @param   t2eAttachment       The class representation of the attachment
     * @param   strCLEsbuName       The user-submitted esbu doc name
     *
     * @return  A string containing the formatted attachment name
     */
    private String formatAttachmentName(Attachment t2eAttachment, String strCLEsbuName) throws Exception
    {

        String strJobID = (String)t2eAttachment.ATTRIBUTES.get("att_dqs_jobid");
        String strExecID = (String)t2eAttachment.ATTRIBUTES.get("att_exec_id");
        File tempFile = new File(t2eAttachment.PATH);
        String strFileName = tempFile.getName();
        String strFormattedName = strFileName.trim();

        //
        // Remove the process_id entry as it is not a valid attribute and only exists
        // for this purpose.
        //
        String strProcessID = (String)t2eAttachment.ATTRIBUTES.remove("process_id");
        List<String> arrIdentifiers = new Vector<String>(); 
        
        if(strJobID != null)
        {
            arrIdentifiers.add(strJobID.trim());
        }
        if(strExecID != null)
        {
            arrIdentifiers.add(strExecID.trim());
        }
        if(strProcessID != null)
        {
            arrIdentifiers.add(strProcessID.trim());
        }

        arrIdentifiers.add(createRandomIdentifier());

        //
        // Test the name against all other attachments on the ESBU document
        //            
        if(!P_PARSE_ONLY && !C_GENERATE_CL_OPTS)
        {
            boolean boolIsUnique = false;
            int index = 0;

            try
            {
                //
                // This test only is performed if the user is actually going
                // to upload the attachment. This means the edms document
                // has already been verified to exist.
                //
                IDfSysObject edmsDoc = getEDMSDocument();
                String strEsbuName = edmsDoc.getObjectName().trim();
                String strEsbuRev = edmsDoc.getString("esbu_revision");
                String strEsbuSheet = edmsDoc.getString("esbu_sheet");

                while(!boolIsUnique && index < arrIdentifiers.size())
                {
                    IDfQuery query = null;
                    IDfCollection col = null;
                    int intNumDocs;

                    String strTempAttachName = "";

                    strTempAttachName = replaceSpecialChars(strFileName.trim())+ "_" + arrIdentifiers.get(index) + "_" + strEsbuName;
                    LogUtils.printDebug("      Testing uniqueness of '" + strTempAttachName + "'");  
                    //
                    // Check Attachment uniqueness for the current ESBU doc
                    //
                    String strQuery = "SELECT COUNT(*) AS num_docs " +
                                      "FROM esbu " +
                                      "WHERE object_name='" + strEsbuName + "' ";
                    if (strEsbuRev != null && strEsbuRev.length() > 0)
                    {
                        strQuery = strQuery + "AND esbu_revision='" + strEsbuRev.toUpperCase().replaceAll("'", "''") + "' ";
                    }
                    if (strEsbuSheet != null && strEsbuSheet.length() > 0)
                    {
                        strQuery = strQuery + "AND esbu_sheet='" + strEsbuSheet.toUpperCase().replaceAll("'", "''") + "' ";
                    }

                    strQuery = strQuery + "AND ANY UPPER(att_object_name) like '" + strTempAttachName.toUpperCase() + "%'";
                    LogUtils.printDebug("         Query: " + strQuery);
                    query = new DfQuery();
                    query.setDQL(strQuery);
                    col = query.execute(SESSION, IDfQuery.DF_READ_QUERY);
                    col.next();
                    intNumDocs = col.getInt("num_docs");
                    if (intNumDocs < 1)
                    {
                        boolIsUnique = true;
                        strFormattedName = strTempAttachName;
                        LogUtils.printDebug("            PASS");
                    }
                    else
                    {
                        LogUtils.printDebug("            FAIL");
                    }
                    index++;
                }
            }
            catch(Exception e)
            {
                LogUtils.handleError("[ERROR] An error occurred during the attachment name formatting.", e);
                throw e;
            } 
        }
        else
        {
            strFormattedName = replaceSpecialChars(strFileName) + "_" + arrIdentifiers.get(0) + "_" + strCLEsbuName;
        }
 
        return strFormattedName;
    }
 
    /**
     * This method generates an indentifier by converting the current system time
     * into seconds. It sleeps for one second prior to doing so to ensure that
     * a unique time is given if multiple attachments are being processed at the
     * same time.
     *
     * @return String representation of the current system time in seconds.
     */   
    private String createRandomIdentifier() 
    {
        try { Thread.sleep(1000);} catch(InterruptedException ex) {}        
        return Long.toString(System.currentTimeMillis() / 1000).trim();
    }

    /**
     * This method replaces all of the special characters in a string with an
     * underscore.
     *
     * @param   strName     The string to format
     *
     * @return  A string representation of the correctly formmatted name.
     */    
    private String replaceSpecialChars(String strName)
    {
        char arrCharsToReplace[] = {' ', '(', ')', '=', '+', '*', '&', '^', '%', '$', '#', '@', '!', '[', ']', '{', '}', '<', '>', '/', '\\', '?', '|', '~', '`', ':', ';', ',', '\'', '\"'};
        for(int y = 0; y < arrCharsToReplace.length; y++)
        {
            strName = strName.replace(arrCharsToReplace[y], '_');
        }    
        return strName;
    }

    /**
     * This method is called when the user is in a 'display only' mode (the -P 
     * and -C flags). This will print out all of the parsed, passed, and proccessed
     * information of the attachments.
     *
     * @param   t2eAttachment       The object representing the Attachment metadata
     * @param   t2eOptionHandler    The argument parser class
     * @param   hEsbuAttributes     The hashtable containing the esbu doc information
     *
     * @return  A string containing all of the attribute information about the document.
     */
    private String displayAttachmentAttributes(Attachment t2eAttachment, T2EOptionHandler t2eOptionHandler, Hashtable<String,Object> hEsbuAttributes)
    {
        String strOutput = "";   
        String strNewline = "";
        List<String> arrDisplayOrder = T2EConfig.getDisplayOrder();
        List<String> arrNeedQuotations = T2EConfig.getAttrsNeedQuotes();
        t2eAttachment.ATTRIBUTES.put("file_type", t2eAttachment.FORMAT);

        if(C_GENERATE_CL_OPTS)
        {
            t2eAttachment.ATTRIBUTES.remove("att_object_name");
            t2eAttachment.ATTRIBUTES.remove("object_name"); // Remove the attachment's (potentially formatted) name
            Enumeration<String> keys = hEsbuAttributes.keys();
            while (keys.hasMoreElements())
            {
                String strKey = keys.nextElement();
                String strValue = (String)hEsbuAttributes.get(strKey); // hEsbuAttributes only contains strings
                t2eAttachment.ATTRIBUTES.put(strKey,strValue);
            }
        }

        for(String strAttribute : arrDisplayOrder)
        {   
            if(t2eAttachment.ATTRIBUTES.containsKey(strAttribute))
            {             
                Object obj = t2eAttachment.ATTRIBUTES.get(strAttribute);               
                if(obj instanceof List)
                {
                    List<String> arrValues = T2EConfig.toGenericList((List)obj);
                    for (String strValue : arrValues)
                    {
                        if(P_PARSE_ONLY && strValue != null && strValue.length() > 0)
                        {
                                strOutput = strOutput + strNewline + strAttribute + ":" + strValue;
                                strNewline = System.getProperty("line.separator");
                        }
                        else if(C_GENERATE_CL_OPTS && strValue != null && strValue.length() > 0)
                        {
                            if(arrNeedQuotations.contains(strAttribute))
                            {
                                strValue = "\"" + strValue + "\"";
                            }
                            strOutput = strOutput + "-" + t2eOptionHandler.getOptionIdentifier(strAttribute) + " " + strValue + " ";
                        }                     
                    }
                }
                else if (obj instanceof String)
                {
                    String strValue = (String)obj;
                    if(P_PARSE_ONLY && strValue != null && strValue.length() > 0)
                    {
                        strOutput = strOutput + strNewline + strAttribute + ":" + strValue;
                        strNewline = System.getProperty("line.separator");
                    }
                    else if(C_GENERATE_CL_OPTS && strValue != null && strValue.length() > 0)
                    {
                        if(arrNeedQuotations.contains(strAttribute))
                        {
                            strValue = "\"" + strValue + "\"";
                        }
                        strOutput = strOutput + "-" + t2eOptionHandler.getOptionIdentifier(strAttribute) + " " + strValue + " ";
                    }                
                }
            }
        }

        return strOutput;
    }
    
    /**
     * The following are the getters & setters of the program. They're pretty
     * self explainatory. Any that require extra detail will be commented
     */
    /**
     * Sets the docbase
     *
     * @param strDocbase    The docbase value
     */
    private void setDocbase(String strDocbase)
    {
        DOCBASE = strDocbase.toLowerCase();
    }

    /**
     * Returns the docbase value
     *
     * @return  The docbase name
     */
    private String getDocbase()
    {
        return DOCBASE;
    }

    /**
     * Sets the docbase logic to be used by the banners
     *
     * @param strDocbaseLogic    The docbase value
     */
    private void setDocbaseLogic(String strDocbaseLogic)
    {
        DOCBASE_LOGIC = strDocbaseLogic.toLowerCase();
    }    

    /**
     * Returns the docbase logic value to be utilized by the banners
     *
     * @return  The docbase name
     */
    private String getDocbaseLogic()
    {
        return DOCBASE_LOGIC;
    }

    /**
     * Sets the script name
     *
     * @param strScriptName     The name of the script being used
     */
    private void setScriptName(String strScriptName)
    {
        SCRIPT_NAME = strScriptName;
    }

    /**
     * Sets the log file path
     * @param strLogFile    The path to the log file
     */
    private void setLogFile(String strLogFile)
    {
        LOG_FILE = strLogFile;
    }

    /**
     * Sets the documentum session
     *
     * @param session   The established session to documentum
     */
    private void setSession(IDfSession session)
    {
        SESSION = session;
    }

    /**
     * Retrieves the logfile path
     *
     * @return  The path to the log file
     */
    public static String getLogFile()
    {
        return LOG_FILE;
    }

    /**
     * Returns the debug mode flag
     * @return  True if the -debug flag was encountered
     */
    public static boolean getDebug()
    {
        return DEBUG;
    }

    /**
     * Records the EDMS object
     *
     * @param strQualification  Qualification string indentifiying the EDMS object
     * @throws DfException
     *
     */
    private void setEDMSDocument(String strQualification) throws DfException
    {
        EDMS_DOC =(IDfSysObject)SESSION.getObjectByQualification(strQualification);
    }

    /**
     * Retrieves the stored EDMS object
     *
     * @return  The pointer to the EDMS document
     * @throws DfException
     */
    private IDfSysObject getEDMSDocument() throws DfException
    {
        return EDMS_DOC;
    }

    /**
     * Sets the debug mode flag
     * @param debugMode     The value to set the debug flag
     */
    private void setDebugMode(boolean debugMode)
    {
        DEBUG = debugMode;
    }

    /**
     * Gets the debug mode for text2edms
     * 
     * @return True if in debug mode
     */
    public boolean getDebugMode()
    {
        return DEBUG;
    }
    /**
     * Retrieves the script name
     * @return  The name of the T2E script being used
     */
    private String getScriptName()
    {
        return SCRIPT_NAME;
    }

    /**
     * Incrememts the successful-upload counter.
     */
    private void incrementSuccess()
    {
        SUCCESS++;
    }

    /**
     * Increments the failed-upload counter
     */
    private void incrementFailure()
    {
        FAILURES++;
    }

    /**
     * Returns the successful-upload counter
     * @return  The number of successes
     */
    public int getSuccesses()
    {
        return SUCCESS;
    }

    /**
     * Returns the failed-upload counter
     * @return  The number of failures
     */
    public int getFailures()
    {
        return FAILURES;
    }

    /**
     * Sets the total number of attachments passed by the user
     * @param size  The number of attachments
     */
    private void setTotalAttachments(int size)
    {
        TOTAL_ATTACH = size;
    }

    /**
     * Returns the total number of attachments passed by the user
     * @return  The number of attachments
     */
    public int getTotalAttachments()
    {
        return TOTAL_ATTACH;
    }

    /**
     * Sets whether or not to zip attachments
     * @return  True if zip process is needed
     */
    private boolean doZipAttachments()
    {
        return ZIP_ATTACHMENTS;
    }

    /**
     * Sets whether or not to zip attachments
     * @param doCompressFile    The value to set the compression flag
     */
    private void setZipAttachments(boolean doCompressFile) 
    {
        ZIP_ATTACHMENTS = doCompressFile;        
    }    
    
    /**
     * This method will add '_QA' to any user submitted attribute values that are
     * forced to override the parsed values; which is accomplished by looping 
     * putting the suffix on the attributes nn the cmd line hash.
     *
     * While the post pending will always occur in docnfd, the results will not
     * be seen if the -f flag isn't used because that is the only way that
     * the cmd line attributes will override the parsed values.
     *
     * @param   hCLAttributes       Hashtable of cmd line (user submitted) attributes
     *
     */
    private void postPendAttributes(Hashtable<String, Object> hCLAttributes)
    {
        Enumeration<String> keys = hCLAttributes.keys();
        String strPostPend = T2EConfig.getConfigString(getDocbaseLogic() + ".postpend.suffix");

        if(strPostPend != null && strPostPend.trim().length() > 0) //&& hParsedAttributes != null)
        {
            while (keys.hasMoreElements())
            {
                String strKey = keys.nextElement();
                //if(hParsedAttributes.containsKey(strKey))
                if(!strKey.equalsIgnoreCase("authors") && !strKey.equalsIgnoreCase("keywords"))
                {
                    Object objValue = hCLAttributes.remove(strKey);
                    if (objValue instanceof String)
                    {
                        hCLAttributes.put(strKey,(String)objValue + strPostPend);
                    }
                    else if (objValue instanceof List)
                    {
                        List<String> arrValues = T2EConfig.toGenericList((List)objValue);
                        List<String> arrPostPend = new Vector<String>();
                        for (String strValue : arrValues)
                        {
                            strValue = strValue + strPostPend;
                            arrPostPend.add(strValue);
                        }
                        hCLAttributes.put(strKey, arrPostPend);
                    }
                }
            }
        }
    }

    /**
     * This prints the current verion of Text2EDMS. It makes sure to print the 
     * current script name instead of just 'text2edms' to avoid confusion.
     *
     */
    private void printT2EVersion()
    {
        System.out.println("*************   " + getScriptName() + " Version " + T2EConfig.getVersionNumber() + "   ***************");
        System.out.println("*                                                     *");
        System.out.println("* Copyright " + T2EConfig.getCopyright() + "   sample Electric Company      *");
        System.out.println("*             All Rights Reserved                     *");
        System.out.println("*     sample Proprietary - Class 2              *");
        System.out.println("*                                                     *");
        System.out.println("*******************************************************");
    }
    
}