/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.sample.custom.text2edms.program;

import java.io.*;
import java.util.*;

/**
 * Reads & returns specified properties from the configuration file
 * @author crittedp
 */
public class T2EConfig
{
    private static Properties CONFIG = null;

    /**
     * Initializes (loads) the configuration file.
     *
     * @param   inConfigFile    The config file to be read
     *
     */
    public static void initConfigFile(InputStream inConfigFile)
                                      throws FileNotFoundException, IOException
    {
        //System.out.println("INITCONFIGFILE");
        CONFIG = new Properties();
        CONFIG.load(inConfigFile);
    }

    /**
     * Reads & returns the specified property from the config file
     *
     * @param   strProperty     The property to be read from the config file
     *
     * @return  The value found in the config file.
     */
    protected static String getConfigString(String strProperty)
    {
        String strValue = CONFIG.getProperty(strProperty);
        if (strValue != null && strValue.length() == 0)
        {
            return null;
        }
        else
        {
            return strValue;
        }
    }

    /**
     * Reads & returns the specified property from the config file
     *
     * @param   strProperty     The property to be read from the config file
     * @param   boolDefault     The default value
     *
     * @return  The value found in the config file or the default value if the
     * property was not found.
     */
    protected static boolean getConfigBoolean(String strProperty, boolean boolDefault)
    {
        String strValue = CONFIG.getProperty(strProperty);
        if (strValue == null || strValue.length() == 0)
        {
            return boolDefault;
        }
        else if (strValue.trim().equalsIgnoreCase("true") ||
                 strValue.trim().equalsIgnoreCase("T"))
        {
            return true;
        }
        else if (strValue.trim().equalsIgnoreCase("false") ||
                 strValue.trim().equalsIgnoreCase("F"))
        {
            return false;
        }
        else
        {
            return boolDefault;
        }
    }

    /**
     * Reads & returns the specified property from the config file
     *
     * @param   strProperty     The property to be read from the config file
     * @param   intDefault      The default value
     *
     * @return  The value found in the config file or the default value if the
     * property was not found.
     */
    protected static int getConfigInteger(String strProperty, int intDefault)
    {
        String strValue = CONFIG.getProperty(strProperty);
        if (strValue == null)
        {
            return intDefault;
        }
        try
        {
            return Integer.parseInt(strValue.trim());
        }
        catch (Exception e)
        {
            return intDefault;
        }
    }

    /**
     * Reads & returns the specified property from the config file
     *
     * @param   strProperty     The property to be read from the config file
     *
     * @return  The value found in the config file.
     */
    protected static List<String> getConfigList(String strProperty)
    {
        String strAllValues = CONFIG.getProperty(strProperty);
        if (strAllValues == null || strAllValues.length() == 0)
        {
            return new Vector<String>();
        }

        String[] arrValues = strAllValues.split(",");
        Vector<String> v = new Vector<String>(arrValues.length);
        for (String strValue : arrValues)
        {
            v.add(strValue.trim());
        }
        return v;
    }

    /**
     * This converts the given List<Object> to a List<String>. This helps to
     * avoid java warnings.
     *
     * @param   arrValues   A list of objects
     *
     * @return  A list of strings
     */
    @SuppressWarnings("unchecked")
    public static List<String> toGenericList(List arrValues)
    {
        return (List<String>)arrValues;
    }

    /////////////////////////////////////////////////////////
    /////////////     Text2EDMS Config Items     ////////////
    /////////////////////////////////////////////////////////

    /**
     * Retrieves a list of attributes from the config file. This list is used to determine in what
     * order to display the processed attributes.
     *
     * @return  An ordered list of attribute names
     */
    public static List<String> getDisplayOrder()
    {
        return T2EConfig.getConfigList("t2e.attr.order");
    }

    /**
     * Retrieves a list of attribute names from the config file. This list is used to determine which
     * attributes should be surrounded by quotes when they're displayed.
     *
     * @return  List of attribute names
     */
    public static List<String> getAttrsNeedQuotes()
    {
        return T2EConfig.getConfigList("t2e.attr.quotes");
    }

    /**
     * Retrieves the t2e version number from the config file
     *
     * @return  The t2e version number
     */
    public static String getVersionNumber()
    {
        return T2EConfig.getConfigString("t2e.version");
    }

    /**
     * Retrieves the t2e copyright year from the config file
     *
     * @return  The t2e copyright year
     */
    public static String getCopyright()
    {
        return T2EConfig.getConfigString("t2e.copyright");
    }

    /**
     * Retrieves the EDMS attachment cabinet path from the config file
     * @return  The location to upload the attachments
     */
    public static String getAttachmentLinkDir(String strDocbase)
    {
        return T2EConfig.getConfigString(strDocbase + ".attach.cabinet");
    }

    /**
     * Retrieves the attachment owner from the config file. This is usually dmadmin.
     *
     * @return The owner name
     */
    public static String getOwnerName(String strDocbase)
    {
        return T2EConfig.getConfigString(strDocbase + ".attach.owner");
    }

    /**
     * Retrieves the attachment ACL from the config file
     * @return  The ACL name
     */
    public static String getACLName(String strDocbase)
    {
        return T2EConfig.getConfigString(strDocbase + ".attach.acl.name");
    }

    /**
     * Retrieves the ACL domain from the config file
     * @return  The ACL domain name
     */
    public static String getACLDomain(String strDocbase)
    {
        return T2EConfig.getConfigString(strDocbase + ".attach.acl.domain");
    }

    /**
     * Retrieves the number of banner parsers from the config file
     * @return  The number of available banner parsers
     */
    public static int getBannerCount()
    {
        return T2EConfig.getConfigInteger("banner.count", 0);
    }

    /**
     * Retrieves the specified banner's docbase values from the config file
     * @param x     The specified banner number
     * @return  The docbases the banner can be used in
     */
    public static List<String> getBannerDocbase(int x)
    {
        return T2EConfig.getConfigList("banner." + x + ".docbase.names");
    }

    /**
     * Retrieves the specified banner's docbase values from the config file
     * @param x     The specified banner number
     * @return  The docbases the banner can be used in
     */
    public static List<String> getBannerDocbaseLogic(int x)
    {
        return T2EConfig.getConfigList("banner." + x + ".docbase.logic");
    }

    /**
     * Retrieves the specified banner's classpath from the config file
     * @param intBannerNum  The specified banner number
     * @return  The path to the banner's behavior class
     */
    public static String getBannerClassPath(int intBannerNum)
    {
        return T2EConfig.getConfigString("banner." + intBannerNum + ".class");
    }

    /**
     * Retrieves the default content type from the config file
     * @return  The content type to default to
     */
    public static String getDefaultContentType(String strDocbase)
    {
        return T2EConfig.getConfigString(strDocbase + ".default.format");
    }

    /**
     * Sets whether or not to zip attachments by default as defined by the config file
     */
    public static boolean getZipByDefault(String strDocbase)
    {
        return T2EConfig.getConfigBoolean(strDocbase + ".zip.default", false);
    }

    /**
     * Retrieves the default zipping format from the config file
     * @return  The default zipping format (usually gzip)
     */
    public static String getZipFormat(String strDocbase)
    {
        return T2EConfig.getConfigString(strDocbase + ".zip.format.default");
    }

    /**
     * Retrieves the unzippable formats from the config file
     * @return  A list of non-zippable formats
     */
    public static List<String> getNonZippableFormats(String strDocbase)
    {
        return T2EConfig.getConfigList(strDocbase + ".zip.format.skip");
    }

    /**
     * Sets which formats should not be parsed
     */
    public static List<String> getNonParseableFormats()
    {
        return T2EConfig.getConfigList("t2e.format.skip");
    }

    /**
     * This function is used to auto-assign formats to a given extention if said
     * extention is known to map to multiple formats. These values are read from
     * the config file.
     *
     * Example: .doc is forced to map to msw8 because it has 10 other dm_formats
     *
     * @return  A hashtable where the key is the extension and the dm_format is
     * the value.
     */
    public static Hashtable<String, String> getForcedFormatMap()
    {
        //
        // Side note: The values from the config file were populated via:
        // select dos_extension, count(*) from dm_format group by dos_extension having count(*) > 1
        //
        Hashtable<String,String> hTable = new Hashtable<String,String>();
        int intFormatCount = T2EConfig.getConfigInteger("t2e.format.map.count", 0);

        for(int x=1; x <= intFormatCount; x++)
        {
            String strExtension = T2EConfig.getConfigString("t2e.format.map." + x + ".name");
            String strFormat = T2EConfig.getConfigString("t2e.format.map." + x + ".value");
            if(strExtension != null && strFormat != null)
            {
                hTable.put(strExtension, strFormat);
            }
        }
        return hTable;
    }

    /**
     * Determines if the program should postpend a string on the end of a value.
     * @return  True if postpending is necessary.
     */
    public static boolean needPostPend(String strDocbase)
    {
        return T2EConfig.getConfigBoolean(strDocbase + ".postpend.allow", false);
    }

    /////////////////////////////////////////////////////////
    ///////////   T2EOptionHandler Config Items     /////////
    /////////////////////////////////////////////////////////

    /**
     * This method returns a list of depricated options (flags)
     *
     * @return A list of deprecated options.
     */
    public static List<String> getDeprecatedOptions()
    {
        return T2EConfig.getConfigList("options.deprecated.values");
    }

    /**
     * This method retrieves the Deprecated Option message from the config file.
     *
     * @return A message specifying that the option has been deprecated.
     */
    public static String getDeprecatedMessage()
    {
        return T2EConfig.getConfigString("options.error.deprecated");
    }

    /**
     * This method retrieves the Already Selected Option message from the config
     * file.
     *
     * @return  A message specifying that the option has already been passed in.
     */
    public static String getAlreadySelectedErrorMessage()
    {
        return T2EConfig.getConfigString("options.error.ase");
    }

}
