/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.sample.custom.sample.program;

import java.util.*;
import java.util.regex.*;

/**
 * Generic banner parser class.
 * @author crittedp
 */
public abstract class T2EBanner
{
    private int BANNER_NUMBER = 0;
    private int REGEX_COUNT = 0;
    private int REGEX_POSITION = 1;
    private String BANNER_CLASS = "";
    private String BANNER_NAME = "";
    private String BANNER_START_PATTERN = "";
    private String BANNER_END_PATTERN = "";
    private String REGEX_PATTERN = "";
    private int REGEX_ATTR_COUNT = 0;
    private boolean PARSING_COMPLETE = false;
    private boolean IS_SELECTED = false; // Specifies whether or not this Banner is the 'chosen one' :)
    private Hashtable<String,Object> PARSED_ATTRIBUTES = new Hashtable<String,Object>();
    private int BANNER_START_COUNT;
    private int BANNER_END_COUNT;
    private int BANNER_START_ENCOUNTERS = 0;
    private int BANNER_END_ENCOUNTERS = 0;
    private String DOCBASE = "";

    /**
     * Initializes the banner, setting the name, class path, and the start, end
     * & initial search regexes to the values in the config file for the specified
     * banner number.
     *
     * @param   strBnrNum       The number of the banner - used by the config file
     *
     * @return  True if it initialized properly.
     */
    public boolean init(int strBnrNum, String strDocbase) throws Exception
    {
        setBannerDocbase(strDocbase);
        setBannerInfo(strBnrNum);
        setRegexCount();
        setRegexPosition(1);
        setRegexPattern();
        setRegexAttributeCount();     
        setFinished(false);
        setSelected(false); 
        getParsedAttributes().clear(); 
        resetBannerEncounters();

        LogUtils.printDebug("   BANNER ATTRIBUTES:");
        LogUtils.printDebug("      Number: " + getBannerNumber());
        LogUtils.printDebug("      Name: " + getName());
        LogUtils.printDebug("      Docbase: " + getBannerDocbase());
        LogUtils.printDebug("      Class Path: " + getClassName());
        LogUtils.printDebug("      Start Pattern: " + getBannerStartPattern());
        LogUtils.printDebug("      End Pattern: " + getBannerEndPattern());
        LogUtils.printDebug("      Initial Regex: " + getRegexPattern());
        LogUtils.printDebug("         Complete");
        return true;
    }
    /**
     * Resets all of the banner's information
     * @throws Exception
     */
    public void reset() throws Exception
    {
        LogUtils.printDebug("         " + getName());
        setBannerInfo(getBannerNumber());
        setRegexCount();
        setRegexPosition(1);
        setRegexPattern();
        setRegexAttributeCount();
        setFinished(false);
        setSelected(false);
        getParsedAttributes().clear();
        resetBannerEncounters();
    }
    /*
     * We have to test the line before parsing the line. The initial testing activates
     * the 'isSelected()' which will cause the second call to parseLine to actually record the parsing.
     */

    /**
     * This method is used to test the line before any parsing takes place.
     * The initial testing activates the 'isSelected()' (if the line matches the
     * start pattern) which will cause sample to initiate a direct call to
     * the parseLine function to actually perform the parsing action.
     *
     * @param   strLine     The line to be tested
     *
     * @return  True if the line matches the start pattern.
     */
    public boolean testLine(String strLine) throws Exception
    {
        return parseLine(strLine);
    }

    /**
     * This function performs different functions depending on the class's state.
     * If this banner parser is not selected (isSelected() == false), it will
     * compare the current input line to the banner's identification regex and
     * will set isSelected() based on the results of the comparison. Once this
     * parser is selected, this method attempts to parse the current regular
     * expression (regex) from the passed in line. If it matches the pattern,
     * the appropriate information is recorded in the classes parsed attributes
     * hashtable. If it doesn't match, the current line is compared to the end
     * pattern for the banner. This method will mark the class as finished
     * (isFinished() == true) when either the end pattern is encountered or
     * all of the regexs are fulfilled.
     *
     *
     * @param   strLine     The current line to parse
     *
     * @return  True if the line matches the current regex.
     */
    public boolean parseLine(String strLine) throws Exception
    {
        Pattern pattern = null;
        Matcher matcher = null;
        Pattern patBannerStart = Pattern.compile(getBannerStartPattern().trim());
        Pattern patBannerEnd = Pattern.compile(getBannerEndPattern().trim());

        //
        // If this banner has been selected
        //
        if(isSelected())
        {
            if(getRegexPattern() != null)
            {              
                pattern = Pattern.compile(getRegexPattern().trim());
                matcher = pattern.matcher(strLine);
               //matcher.reset(strLine);
               LogUtils.printDebug("      Regex: " + pattern.pattern());
               if(matcher.find())
               {
                   LogUtils.printDebug("         Found!");
                   int numGroups = matcher.groupCount();
                   String strAttributeName = "";

                   if(getRegexAttributeCount() > 0)
                   {
                       if (getRegexAttributeCount() == numGroups)
                       {
                           for(int x=1; x <= numGroups; x++)
                           {
                                 strAttributeName = getRegexAttr(x);
                                 setParsedAttributes(strAttributeName, matcher.group(x), getRegexAttrRepeating(x));
                           }
                       }
                       else
                       {
                           //Do nothing

                       }
                   }
                   else
                   {
                       LogUtils.printDebug("      No attributes to parse");
                   }

                   /*
                    * We always increment the REGEX_POSITION if we've entered the
                    * "matched" block, even if we don't successfully parse the values
                    * from the input. This ensures the regex changes everytime
                    * instead of getting hung up on a single pattern.
                    */
                   incrementRegexPosition();
                   if(getRegexPosition() > getRegexCount())
                   {
                       LogUtils.printDebug("         Maximum number of regexs reached!");
                       setFinished(true);
                   }
                   else
                   {
                       setRegexPattern();
                       setRegexAttributeCount();
                   }
               }
               else
               {
                   /*
                    * Always check to see if we've reached the end of the banner
                    * if the current input does not match the regex.
                    */
                    LogUtils.printDebug("         No match!");
                 /*  pattern = Pattern.compile(BANNER_END_PATTERN);
                   matcher = pattern.matcher(strLine);
                   matcher.reset(strLine);*/

                    if(testBannerEnd(patBannerEnd.matcher(strLine).find()))
                    {
                        LogUtils.printDebug("      Banner End Reached");
                        setFinished(true);
                    }
               }
            }
            else if(testBannerEnd(patBannerEnd.matcher(strLine).find()))
            {
                LogUtils.printDebug("      Banner End Reached");
                setFinished(true);               
            }
            //
            // Log that the current line didn't match the regex but return true
            // The current regex will be searched for until either it is found
            // or the end of the banner is encountered.
            // 
            return true;
        }
        else
        {
            /*
             * If the isSelected == false then compare the current input line
             * to the banner's identification regex. Set isSelected() based on
             * the comparison
             */
            setSelected(testBannerStart(patBannerStart.matcher(strLine).find()));
            return isSelected();
        }
    }

    /**
     * This method records the parsed attributes in the hashtable if the name &
     * value are not null or empty.
     *
     * @param   strAttrName     The attribute name
     * @param   strAttrValue    The attribute value
     *
     */
    public void setParsedAttributes(String strAttrName, String strAttrValue, boolean isRepeating) throws Exception
    {
        if(strAttrName != null && strAttrValue != null && strAttrValue.trim().length() > 0)
        {
            if(!isRepeating)
            {
                LogUtils.printDebug("         Setting attribute: '" + strAttrName + 
                        "'    Value: '" + strAttrValue.trim() + "' Repeating: " + isRepeating);
                getParsedAttributes().put(strAttrName, strAttrValue.trim());
            }
            else
            {
                if(!getParsedAttributes().containsKey(strAttrName))
                {
                    List<String> arrAttr = new Vector<String>();
                    arrAttr.add(strAttrValue);
                    LogUtils.printDebug("         Setting attribute: '" + strAttrName + 
                            "'    Adding Value: '" + strAttrValue.trim() + "' Repeating: " + isRepeating);
                    getParsedAttributes().put(strAttrName, arrAttr);
                }
                else
                {
                    LogUtils.printDebug("         Setting attribute: '" + strAttrName + 
                            "'    Value: '" + strAttrValue.trim() + "'" + " Repeating: " + isRepeating);
                    List<String> arrAttr = T2EConfig.toGenericList((List)getParsedAttributes().get(strAttrName));
                    arrAttr.add(arrAttr.size(),strAttrValue);
                    getParsedAttributes().put(strAttrName, arrAttr);
                }
            }
        }
    }


    /**
     *  This function retrieves the recorded attributes.
     *
     * @return  A hashtable containing the parsed attributes. The key is the
     * attribute name (label).
     */
    public Hashtable<String, Object> getParsedAttributes()
    {
        return PARSED_ATTRIBUTES;
    }
    

   /**
    * Reads the total number of regular expressions for the banner from the 
    * config file. 
    */
    public void setRegexCount()
    {
        REGEX_COUNT = T2EConfig.getConfigInteger("banner." + BANNER_NUMBER + ".regex.count", 0);
    }
    
    /**
     * Manually override the number of regular expressions.
     *
     * @param  intCount     The number of desired regexs
     */
    protected void overrideRegexCount(int intCount)
    {
        REGEX_COUNT = intCount;
    }
    
    /**
     * Function to retrieve the number of regular expressions.
     * 
     * @return  The number of regexs
     */
    public int getRegexCount()
    {
        return REGEX_COUNT;
    }
        
    /**
     * Records the current regular expression from the config file.
     */
    public void setRegexPattern()
    {
        REGEX_PATTERN = T2EConfig.getConfigString("banner." + BANNER_NUMBER + ".regex." + REGEX_POSITION + ".pattern");
    }
    
    /**
     * Sets the number of attributes expected to be captured by the regex pattern.
     */    
    public void setRegexAttributeCount()
    {
        REGEX_ATTR_COUNT = T2EConfig.getConfigInteger("banner." + BANNER_NUMBER + ".regex." + REGEX_POSITION + ".attr.count",0);
    } 
    
    /**
     * Sets the position used to read the regular expression from the config file.
     * 
     * @param   intPosition     The regex position within the config file
     */
    public void setRegexPosition(int intPosition)
    {
        REGEX_POSITION = intPosition;
    }     
    
    /**
     * Overrides the current regex position with the passed in number.
     * 
     * @param   intPosition     The regex position within the config file
     */
    protected void overrideRegexPosition(int intPosition)
    {
        REGEX_POSITION = intPosition;
    }    
    
    /**
     * Increments the current regex position.
     */
    public void incrementRegexPosition()
    {
        REGEX_POSITION++;
    }
          
    /**
     * Returns the current position in the config file.
     * 
     * @return  The current regex number being read from the config file.
     */
    public int getRegexPosition()
    {
        return REGEX_POSITION;
    }    
    
    /**
     * Returns the regular expression pattern.
     * 
     * @return  A string containing the current regex pattern.
     */
    public String getRegexPattern()
    {
        return REGEX_PATTERN;
    }    
    
    /**
     * Returns the expected number of attribute captures.
     * 
     * @return  The number of expected attributes captured by the current regex.
     */
    public int getRegexAttributeCount()
    {
        return REGEX_ATTR_COUNT;
    }    
    
    /**
     * Reads the associated attribute name value from the config file.
     * 
     * @param   index   The location of the attribute name in the config file.
     * 
     * @return  A string containing the attribute name.
     */    
    public String getRegexAttr(int index)
    {
        return T2EConfig.getConfigString("banner." + BANNER_NUMBER + ".regex." + REGEX_POSITION + ".attr." + index);
    }    
    
    /**
     * Reads the repeating feild for a given index. This is used to determine
     * whether or not the attribute is a repeating attribute.
     * 
     * @param   index   The location of the attribute in the config file
     * 
     * @return  True if the attribute is repeating.
     */
    public boolean getRegexAttrRepeating(int index)
    {
        return T2EConfig.getConfigBoolean("banner." + BANNER_NUMBER + ".regex." + REGEX_POSITION + ".attr." + index + ".repeating", false);
    }
    
    /**
     * Reads & records banner information from the config file for a given banner
     * number. This information includes:
     * <ul>
     *      <li> The banner number
     *      <li> The start & end banner regex and count (number of expected encounters)
     *      <li> The banner name
     *      <li> The banner's classpath
     * </ul>
     * 
     * @param   intBnrNum   The number of the banner being initialized
     */
    public void setBannerInfo(int intBnrNum)
    {
        BANNER_NUMBER = intBnrNum;
        BANNER_START_PATTERN = T2EConfig.getConfigString("banner." + BANNER_NUMBER + ".start");
        BANNER_START_COUNT = T2EConfig.getConfigInteger("banner." + BANNER_NUMBER + ".start.count", 0);
        BANNER_END_PATTERN = T2EConfig.getConfigString("banner." + BANNER_NUMBER + ".end");
        BANNER_END_COUNT = T2EConfig.getConfigInteger("banner." + BANNER_NUMBER + ".end.count", 0);
        BANNER_NAME = T2EConfig.getConfigString("banner." + BANNER_NUMBER + ".name");
        BANNER_CLASS = T2EConfig.getConfigString("banner." + BANNER_NUMBER + ".class");
    }    
    
    /**
     * Returns the banner number.
     * 
     * @return  The banner's identification number
     */
    public int getBannerNumber()
    {
        return BANNER_NUMBER;
    }    
    
    /**
     * Retrieves the banner start pattern.
     * 
     * @return  The banner's identificating pattern
     */
    public String getBannerStartPattern()
    {
        return BANNER_START_PATTERN;
    }    
    
    /**
     * Returns the expected number of encounters for the banner's identification
     * pattern.
     * 
     * @return  The number of expected banner identification patterns
     */
    public int getBannerStartCount()
    {
        return BANNER_START_COUNT;
    } 

    /**
     * Retrieves the banner end pattern.
     *
     * @return  The banner's ending pattern
     */
    public String getBannerEndPattern()
    {
        return BANNER_END_PATTERN;
    }

    /**
     * Returns the expected number of encounters for the banner's ending pattern.
     * 
     * @return  The number of expected banner ending patterns
     */
    public int getBannerEndCount()
    {
        return BANNER_END_COUNT;
    }

    /**
     * Returns the banner's name
     *
     * @return  A string containing the banner name
     */
    public String getName()
    {
        return BANNER_NAME;
    }

    /**
     * Reads the secondary field from the config file
     *
     * @return  True if the primary banner has a secondary banner
     */
    public boolean hasSecondaryBanner()
    {
        return T2EConfig.getConfigBoolean("banner." + BANNER_NUMBER + ".secondary", false) ;
    }

    /**
     * Reads the secondary banner's number from the primary banner's section in
     * the config file
     *
     * @return  The identification number for the secondary banner.
     */
    public int getSecondaryBannerNumber()
    {
        return T2EConfig.getConfigInteger("banner." + BANNER_NUMBER + ".secondary.number", 0);
    }

    /**
     * Reads the size of the banner. This is only important if the entire banner
     * is only one line.
     *
     * @return  The number of lines in the banner.
     */
    public int getSize()
    {
        return T2EConfig.getConfigInteger("banner." + BANNER_NUMBER + ".size", 0);
    }

    /**
     * Returns the classpath for the banner
     *
     * @return  The classpath
     */
    public String getClassName()
    {
        return BANNER_CLASS;
    }

    /**
     * Sets whether or not the banner has been selected to parse the file.
     *
     * @param isSelected    Whether or not the banner is selected
     */
    public void setSelected(boolean isSelected)
    {
        IS_SELECTED = isSelected;
    }

    /**
     * Returns whether or not the banner is selected for parsing.
     *
     * @return  True if the banner has been selected
     */
    public boolean isSelected()
    {
        return IS_SELECTED;
    }

    /**
     * Returns whether or not the banner has finished parsing.
     *
     * @param boolComplete  Whether or not the banner has finished.
     */
    public void setFinished(boolean boolComplete)
    {
        PARSING_COMPLETE = boolComplete;
    }

    /**
     * Returns whether or not the banner has finished parsing.
     *
     * @return  True if the parsing is complete.
     */
    public boolean hasFinished()
    {
        return PARSING_COMPLETE;
    }

    /**
     * Method to allow for any post-parsing processing of the attributes. This
     * particular method is generally only utilized by secondary banners.
     *
     * @param hAttributes   Generally the 'Primary Banner' attributes
     *
     * @throws Exception
     */
    public void processParsedAttributes(Hashtable<String, Object> hAttributes) throws Exception
    {
        //Do nothing
        LogUtils.printDebug("         Not Implemented");
    }

    /**
     * Method to allow for any post-parsing processing of the attributes.
     *
     * @throws Exception
     */
    public void processParsedAttributes() throws Exception
    {
        //Do nothing
        LogUtils.printDebug("         Not Implemented");
    }

    /**
     * Used to determine whether to flag that the banner should be selected. This
     * is determined by comparing the number of banner-start patterns encountered
     * to the expected number.
     *
     * @param boolBannerStartFound  Whether or not the current patter matches the
     *                              banner start pattern
     * @return  True if the number of encounters >= expected start count
     * @throws Exception
     */
    public boolean testBannerStart(boolean boolBannerStartFound) throws Exception
    {
        if(boolBannerStartFound)
        {
            LogUtils.printDebug("            Start Banner Found! - Expecting " + getBannerStartCount() + " total encounters.");
            incrementBannerStart();
        }
        if(getNumBannerStartEncounters() >= getBannerStartCount())
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
     * Used to determine whether to flag that the banner has finished. This
     * is determined by comparing the number of banner-end patterns encountered
     * to the expected number.
     *
     * @param boolBannerEndFound  Whether or not the current patter matches the
     *                            banner end pattern
     * @return  True if the number of encounters >= expected end count
     * @throws Exception
     */
    public boolean testBannerEnd(boolean boolBannerEndFound) throws Exception
    {
        if(boolBannerEndFound)
        {
            LogUtils.printDebug("            End Banner Found! - Expecting " + getBannerEndCount() + " total encounters.");
            
            incrementBannerEnd();
        }
        if(getNumBannerEndEncounters() >= getBannerEndCount())
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
     * Increments the number of banner end pattern encounters
     */
    private void incrementBannerEnd()
    {
        BANNER_END_ENCOUNTERS++;
    }

    /**
     * Increments the number of banner start pattern encounters
     */
    private void incrementBannerStart()
    {
        BANNER_START_ENCOUNTERS++;
    }

    /**
     * Returns the number of times the banner's start pattern was encountered
     *
     * @return  The number of encounters
     */
    private int getNumBannerStartEncounters()
    {
        return BANNER_START_ENCOUNTERS;
    }

    /**
     * Resets both the banner start & end counters
     *
     */
    private void resetBannerEncounters()
    {
        BANNER_START_ENCOUNTERS = 0;
        BANNER_END_ENCOUNTERS = 0;
    }

    /**
     * Returns the number of times the banner's end pattern was encountered
     *
     * @return  The number of encounters
     */
    private int getNumBannerEndEncounters()
    {
        return BANNER_END_ENCOUNTERS;
    }

    /**
     * Sets the docbase that this banner information will be uploaded to
     *
     * @param strDocbase    The EDMS docbase
     */
    private void setBannerDocbase(String strDocbase)
    {
        DOCBASE = strDocbase;
    }

    public String getBannerDocbase()
    {
        return DOCBASE;
    }
}