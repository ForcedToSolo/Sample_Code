/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.sample.custom.text2edms.program;

import java.util.*;
import org.apache.commons.cli.*;

/**
 * Class to handle the parsing & processing of command line options.
 *
 * @author crittedp
 */
public class T2EOptionHandler
{
    private Options OPTIONS = null;
    private CommandLine CMD_LINE = null;
    private Options REPEATABLE_OPTIONS_GROUP = new Options();
    private Options ESBU_OPTIONS_GROUP = new Options();  
    private Options ATTACH_OPTIONS_GROUP = new Options();


    /**
     * This method initializes the argument parser by reading in the available
     * options (command line switches) and their properties from the config file.
     */
    public void init()
    {
        OPTIONS = new Options();

        /*
         * Options were added to the config file so that they could be easily
         * depricated. It is recognized that in order to include any new options
         * the code must be modified. Really I just wanted to do it this way cuz
         * I thought it was neat and would save a lot of lines of code.
         */
        int index = T2EConfig.getConfigInteger("options.count", 0);
        for(int x=1; x <= index; x++)
        {
            String strOpt = T2EConfig.getConfigString("options." + x + ".name");
            String strDescription = T2EConfig.getConfigString("options." + x + ".desc");
            String strEDMSAttr = T2EConfig.getConfigString("options." + x + ".attr");
            boolean boolHasArg = T2EConfig.getConfigBoolean("options." + x + ".args.required", true);
            boolean boolIsRepeating = T2EConfig.getConfigBoolean("options." + x + ".args.repeating", false);
            String strType = T2EConfig.getConfigString("options." + x + ".type");
            
            OptionBuilder.withDescription(strDescription);
            if(boolHasArg)
            {
                OptionBuilder.hasArg(boolHasArg);
                OptionBuilder.withArgName(strEDMSAttr);
            }
            else
            {
                OptionBuilder.hasArg(false);
            }
             
            OPTIONS.addOption(OptionBuilder.create(strOpt));
            if(boolIsRepeating)
            {
                setRepeatableOptions(OPTIONS.getOption(strOpt));
            }

            if(strType != null)
            {
                setTypeOptions(strType, OPTIONS.getOption(strOpt));
            }
        }
    }

    /**
     * This method parses the arguments from the command line.
     *
     * @param   args    The command line arguments
     *
     */
    public void parseArguments( String[] args) throws Exception
    {
        try
        {
            CommandLineParser parser = new PosixParser();
            CMD_LINE = parser.parse(OPTIONS, args, false);
        }
        catch (UnrecognizedOptionException ex)
        {
            //
            // Load the list of depricated options from the config file since
            // something unrecognized was passed.
            //
            List<String> arrDeprecatedOptions = T2EConfig.getDeprecatedOptions();
            String strUnknownOpt = ex.getOption();
            String strErrMsg = ex.getMessage();
            if(arrDeprecatedOptions.contains(ex.getOption()))
            {               
                strErrMsg = T2EConfig.getDeprecatedMessage() + " " + strUnknownOpt;
            }
            throw new Exception(strErrMsg);
        }
        catch (AlreadySelectedException ex)
        {
            throw new Exception(ex.getMessage());
        }
        catch (ParseException ex)
        {
            throw new Exception(ex.getMessage());
        }
    }

    /**
     * This method returns the names of the attachments to process.
     *
     * @return A list of attachment names.
     */
    public List getAttachNames()
    {
        return CMD_LINE.getArgList();
    }
  

    /**
     * This method gets the user submitted values for a specified type (attach
     * or esbu). The attributes are distinguished by type to allow for ease of
     * retrieval by the main T2E program.
     *
     * @param   strType     The object type of attributes to return
     *
     * @return  A hashtable containing all cmd line args & values for the given
     * object type.
     */
    public Hashtable<String,Object> getCommandLineArgumentValues(String strType) throws Exception
    {
        Option[] arrOptions = CMD_LINE.getOptions();
        Hashtable<String,Object> hAttributes = new Hashtable<String,Object>();
        for(Option opt : arrOptions)
        {            
            if(opt.hasArg())
            {
                if(isTypedAttribute(strType, opt.getOpt()))
                {
                    //
                    // Test to see if the option already exists in the hashtable.
                    // If it already exists and it is a repeatable attribute
                    // then create/add it to a list object and add the list to 
                    // the hashtable. Otherwise, throw an exception.
                    //
                    if(hAttributes.containsKey(opt.getArgName()))
                    {                     
                        if(isRepeatableOption(opt.getOpt()))
                        {
                            if(opt.getValuesList() != null)
                            {
                                List<String> arrExistingValues = null;
                                Object obj = hAttributes.get(opt.getArgName());
                                if(obj instanceof List)
                                {
                                    arrExistingValues = T2EConfig.toGenericList((List)obj);
                                }
                                else
                                {
                                    arrExistingValues = new Vector<String>();
                                    arrExistingValues.add(obj.toString());
                                }
                                arrExistingValues.add(opt.getValue());
                                hAttributes.put(opt.getArgName(), arrExistingValues);
                            }
                        }
                        else
                        {
                            throw new Exception(T2EConfig.getAlreadySelectedErrorMessage() + " " + opt.getOpt());
                        }
                    }
                    else
                    {
                        if(opt.getValue() != null)
                        {
                            hAttributes.put(opt.getArgName(), opt.getValue());
                        }
                    }
                }
            }
        }
        return hAttributes;
    }

    /**
     * This method is used to return a hashtable containing a mapping of attribute
     * names to their associated flag/switch/option value.
     *
     * This is currently unused.
     *
     * @return  Hashtable containing a mapping of attribute names to their
     * associated flag/switch/option value.
     */
    public Hashtable<String,String> getArgumentIdentifier()
    {
        Option[] arrOptions = CMD_LINE.getOptions();
        Hashtable<String,String> hArgIdentifiers = new Hashtable<String,String>();
        for(Option opt : arrOptions)
        {
            hArgIdentifiers.put(opt.getArgName(), opt.getOpt());
        }
        return hArgIdentifiers;
    }

    /**
     * This method is used to return the option/flag/switch identifier for a
     * given attribute name. This is used for the 'generate cl options' portion
     * of the T2E class.
     *
     * @param   strAttribute    The attribute used to retrieve the option flag.
     *
     * @return  String representation of the associated flag/switch/option value
     */
    public String getOptionIdentifier(String strAttribute)
    {
        Collection col = OPTIONS.getOptions();
        Object[] objArray = col.toArray();

        for(int x = 0; x< objArray.length; x++)
        {
            Option opt = (Option)objArray[x];
            if(strAttribute.equals(opt.getArgName()))
            {
                return opt.getOpt();
            }
        }      
        return null;
    }

    /**
     * This method determins if an option is in the specified 'type' group.
     *
     * @param   strType     The object type the option belongs to
     * @param   strOpt      The option
     *
     * @return  True if a match is found
     */
    private boolean isTypedAttribute(String strType, String strOpt)
    {
        if(strType.equalsIgnoreCase("attach"))
        {
            return ATTACH_OPTIONS_GROUP.hasOption(strOpt);
        }
        else if(strType.equalsIgnoreCase("esbu"))
        {
            return ESBU_OPTIONS_GROUP.hasOption(strOpt);
        }
        return false;
    }

    /**
     * This method returns whether or not the option is repeatable.
     *
     * @return  True if the option is repeatable.
     */
    public boolean isRepeatableOption(String strOpt)
    {
        return REPEATABLE_OPTIONS_GROUP.hasOption(strOpt);
    }

    /**
     * This method adds the specified option to the repeating options group.
     *
     * @param   option      The option to add to the group.
     *
     */
    private void setRepeatableOptions(Option option)
    {
        REPEATABLE_OPTIONS_GROUP.addOption(option);
    }

    /**
     * This method adds the specified option to the options group for the 
     * specified type.
     *
     * @param   strType     The document type (esbu or attach)
     * @param   option      The option to add to the group
     * 
     */
    private void setTypeOptions(String strType, Option option)
    {
        if(strType.equalsIgnoreCase("attach"))
        {
            ATTACH_OPTIONS_GROUP.addOption(option);
        }
        else
        {
            ESBU_OPTIONS_GROUP.addOption(option);
        }
    }



    /**
     * @return  True if the user passed the specified flag
     */
    public Boolean getParseOnly()
    {
        return CMD_LINE.hasOption("P");
    }
    /**
     * @return  True if the user passed the specified flag
     */
    public boolean getForceCMDValues()
    {
        return CMD_LINE.hasOption("F");
    }
    /**
     * @return  True if the user passed the specified flag
     */
    public boolean getOverwriteParsedValues()
    {
        return CMD_LINE.hasOption("f");
    }
    /**
     * @return  True if the user passed the specified flag
     */
    public boolean getGenerateCMDOptionsFromFile()
    {
        return CMD_LINE.hasOption("C");
    }
    /**
     * @return  True if the user passed the specified flag
     */
    public boolean getDebugMode()
    {
        return CMD_LINE.hasOption("debug");
    }
    /**
     * @return  True if the user passed the specified flag
     */
    public boolean getDoCompressFile()
    {
        return CMD_LINE.hasOption("z");
    }
    /**
     * @return  True if the user passed the specified flag
     */
    public boolean getPrintT2EVersion()
    {
        return CMD_LINE.hasOption("V");
    }
    /**
     * @return  True if the user passed the specified flag
     */
    public boolean hasUserSuppliedFormat()
    {
        return CMD_LINE.hasOption("G");
    }
}