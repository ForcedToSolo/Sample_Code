/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.sample.custom.sample.program;

import java.util.*;
import java.util.regex.*;

/**
 * This class parses the print_config banner
 * @author crittedp
 */
public class PCBanner extends T2EBanner
{

    private boolean IS_CONFIGURATION_BANNER = false;

    /**
     * The PCBanner parseline will handle the parsing of the print_config banner
     * in all of its forms. It expects that the config control information section
     * will be presented before the execution information section, if it exists.
     *
     * This parseLine method first determines what section is encountered and will
     * update the regex pointers accordingly to ensure the proper information is
     * parsed from whatever section is found.
     *
     * @param strLine   The read in line
     *
     * @return  Always returns true unless performing the selection process.
     *  Whether or not the banner is selected will be returned during the selection process.
     *
     * @throws Exception
     */
    @Override
    public boolean parseLine(String strLine) throws Exception
    {
        Pattern pattern = null;
        Matcher matcher = null;
        Pattern patBannerStart = Pattern.compile(getBannerStartPattern());
        Pattern patBannerEnd = Pattern.compile(getBannerEndPattern());
        //LogUtils.printDebug(strLine);

        //
        // If this banner has been selected
        //
        if(isSelected())
        {
            if(getRegexPattern() != null)
            {              
                pattern = Pattern.compile(getRegexPattern());
                matcher = pattern.matcher(strLine);
                LogUtils.printDebug("         Looking for: " + pattern.pattern());
                if(matcher.find())
                {
                  LogUtils.printDebug("            Found!");
                   int numGroups = matcher.groupCount();
                   String strAttributeName = "";

                   if(getRegexAttributeCount() > 0)
                   {
                       
                        if (getRegexAttributeCount() == numGroups)
                        {
                           for(int x=1; x <= numGroups; x++)
                           {
                                strAttributeName = getRegexAttr(x);

                                //
                                // If we're parsing the banner type from the current
                                // line then update the regex information accordingly.
                                //
                                if(strAttributeName.equalsIgnoreCase("banner_type"))
                                {
                                    doSpecialBannerRegexUpdates(matcher.group(x));
                                    setRegexPattern();
                                    setRegexAttributeCount();
                                    return true;
                                }
                                else
                                {
                                    setParsedAttributes(strAttributeName, matcher.group(x),getRegexAttrRepeating(x));
                                }
                           }  
                        }
                   }
                   else
                   {
                       LogUtils.printDebug("               No attributes to parse");
                   }

                   /*
                    * We always increment the REGEX_POSITION if we've entered the
                    * "matched" block, even if we don't successfully parse the values
                    * from the input. This ensures the regex changes everytime
                    * instead of getting hung up on a single pattern.
                    */
                   incrementRegexPosition();

                   if(getRegexPosition() > getRegexCount())
                   {
                       LogUtils.printDebug("         Maximum number of regexs reached!");
                       setFinished(true);
                   }
                   else
                   {
                       setRegexPattern();
                       setRegexAttributeCount();
                   }
                }
                else
                {
                   /*
                    * Always check to see if we've reached the end of the banner
                    * if the current input does not match the regex.
                    */
                   LogUtils.printDebug("         No Match!");
                    if (testBannerEnd(patBannerEnd.matcher(strLine).find()))
                    {
                            LogUtils.printDebug("      Banner End Reached");
                            setFinished(true);                        
                    }
                }
            }
            else if (testBannerEnd(patBannerEnd.matcher(strLine).find()))
            {
                    LogUtils.printDebug("      Banner End Reached");
                    setFinished(true);
            }
            //
            // Log that the current line didn't match the regex but return true
            // to continue the process. The current regex will be searched for
            // until either it is found or the end of the banner is encountered.
            // 
            return true;
        }
        else
        {
            /*
             * If the isSelected == false then compare the current input line
             * to the banner's identification regex. Set isSelected() based on
             * the comparison
             */
            setSelected(testBannerStart(patBannerStart.matcher(strLine).find()));
            
            return isSelected();
        }
    }

    /**
     * This will process the given hashtable of attributes. It will determine
     * the att_program_status based on the configuration date and the parsed
     * config & code statuses. Possible outcomes are:
     * <ul>
     *      <li> No config date, no code status, or no config status maps to UNCONFIGURED
     *      <li> Code status        Config status       Determined Status
     *      <li>    NOT-VALIDATED       CONFIGURED          Tn-CONFIGURED
     *      <li>    VALIDATED           CONFIGURED          CONFIGURED
     * </ul>
     * @param hAttributes
     * @throws Exception
     */
    @Override
    public void processParsedAttributes(Hashtable<String, Object> hAttributes) throws Exception
    {
        //
        // If the current banner is an execution banner, that means the hAttributes
        // is from a configuration banner.
        //
        if(!hAttributes.equals(getParsedAttributes()) && !isConfigBanner())
        {            
            String strCodeStatus = (String)hAttributes.remove("att_program_status"); // Code status comes from the config banner
            String strConfigStatus = (String)getParsedAttributes().remove("att_program_status"); //Config status comes from the exec banner...believe it or not
            String strConfigDate = (String)hAttributes.get("att_configure_date");
            String strProgramStatus = "UNCONFIGURED";

            LogUtils.printDebug("         Config Status: '" + strConfigStatus + "'");
            LogUtils.printDebug("         Config Date: '" + strConfigDate + "'");
            LogUtils.printDebug("         Code Status: '" + strCodeStatus + "'");

            if(strConfigDate != null)
            {
                if(strCodeStatus != null && strConfigStatus != null)
                {
                    if(strCodeStatus.equalsIgnoreCase("NOT-VALIDATED") && strConfigStatus.equalsIgnoreCase("CONFIGURED"))
                    {
                        strProgramStatus = "Tn-CONFIGURED";
                    }
                    else if(strCodeStatus.equalsIgnoreCase("VALIDATED") && strConfigStatus.equalsIgnoreCase("CONFIGURED"))
                    {
                        strProgramStatus = "CONFIGURED";
                    }
                }
                else
                {
                    strProgramStatus = "UNCONFIGURED";
                }
            }
            else
            {
                strProgramStatus = "UNCONFIGURED";
            }
            setParsedAttributes("att_program_status", strProgramStatus, false);
        
        }
        
    }

    /**
     * This method combines the parsed execution day, month, and year into a single value.
     * @throws Exception
     */
    @Override
    public void processParsedAttributes() throws Exception
    {
        //
        // If it is an execution banner
        //
        if(!isConfigBanner())
        {

            String strExecMonth = (String)getParsedAttributes().remove("exec_month");
            String strExecDay = (String)getParsedAttributes().remove("exec_day");
            String strExecYear = (String)getParsedAttributes().remove("exec_year");

            LogUtils.printDebug("         Execution Month: '" + strExecMonth + "'");
            LogUtils.printDebug("         Execution Day: '" + strExecDay + "'");
            LogUtils.printDebug("         Execution Year: '" + strExecYear + "'");

            if(strExecMonth != null && strExecDay != null && strExecYear != null)
            {
                String strExecDate = strExecMonth + " " + strExecDay + ", " + strExecYear;
                setParsedAttributes("att_exec_date", strExecDate, false);
            }
        }
    }

    /**
     * This sets the banner's regex positions and count based on the parsed banner name
     * @param strAttributeName  The banner name
     * @throws Exception
     */
    private void doSpecialBannerRegexUpdates(String strAttributeName) throws Exception
    {
        String strBanner = "";
        LogUtils.printDebug("         Banner Type: " + strAttributeName);
        setIsConfigBanner(strAttributeName.equalsIgnoreCase("CONFIGURATION CONTROL INFORMATION"));
        if(isConfigBanner())
        {
            strBanner = "config";
        }
        else
        {
            strBanner = "exec";
        }
        // overrideRegexCount(
        // Update the regex info appropriately
        //
        overrideRegexCount(T2EConfig.getConfigInteger("banner." + getBannerNumber() + ".regex." + strBanner + ".count", 0));
        overrideRegexPosition(T2EConfig.getConfigInteger("banner." + getBannerNumber() + ".regex." + strBanner + ".start", 1));
 /*       REGEX_COUNT = T2EConfig.getConfigInteger("banner." + BANNER_NUMBER + ".regex." + strBanner + ".count", 0);
        REGEX_POSITION = T2EConfig.getConfigInteger("banner." + BANNER_NUMBER + ".regex." + strBanner + ".start", 1);
        REGEX_PATTERN = T2EConfig.getConfigString("banner." + BANNER_NUMBER + ".regex." + REGEX_POSITION + ".pattern");*/
    }

    /**
     * Sets whether or not the banner is the Configuration Control Information section
     * @param boolResult
     */
    public void setIsConfigBanner(boolean boolResult)
    {
        IS_CONFIGURATION_BANNER = boolResult;
    }
    /**
     * Returns whether or not the banner is the Configuration Control Information section
     * @return  True if the config section is being processed
     */
    private boolean isConfigBanner() 
    {
        return IS_CONFIGURATION_BANNER;
    }
}