/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.sample.custom.text2edms.program;


/**
 *
 * @author crittedp
 */
public class DAYBanner extends T2EBanner
{
    @Override
    public boolean init(int strBnrNum, String strBannerDocbase) throws Exception
    {
        return super.init(strBnrNum, strBannerDocbase);
    }
}