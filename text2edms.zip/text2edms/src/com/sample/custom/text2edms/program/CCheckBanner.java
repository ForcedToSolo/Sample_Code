/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.sample.custom.text2edms.program;

/**
 * Extends the T2EBanner to provide custom processing for the ccheck banner.
 * @author crittedp
 */
public class CCheckBanner extends T2EBanner
{
    /**
     * This method determines the program status of the attachment and removes
     * all non-numeric characters from the execution ID.
     */
    @Override
    public void processParsedAttributes() throws Exception
    {
        String strProgramStatus = (String)getParsedAttributes().remove("att_program_status");
        String strExecID = (String)getParsedAttributes().remove("att_exec_id");
        if(strProgramStatus != null)
        {
            if(strProgramStatus.length() > 0)
            {
                setParsedAttributes("att_program_status", "CONFIGURED", false);
            }
            else
            {
                setParsedAttributes("att_program_status", "UNCONFIGURED", false);
            }
        }
        if(strExecID != null)
        {   LogUtils.printDebug("      Removing non-numerics from execution id...'" + strExecID + "'");
            strExecID = strExecID.replaceAll("[\\D]","");
            if(strExecID.length() > 0)
            {
                setParsedAttributes("att_exec_id", strExecID, false);
            }
        }        
    }
}