SketchTD
========

Tower Defense

Top Level Layout

code
----
code contains ImpactJS and any other first/third party code.  
At the moment I suggest just editing inline.  I think we should add our project 
specific folders right into the ImpactJS directory and then add our files to these.
[JB]

When upgrading to a new impact we'll just paste over the top and list all the diffed
files.  This isn't ideal but I don't like the alternatives.
[JB]

design
------
Any non-code docs that shouldn't be placed in the code directory.  I think we should
place code related docs (like README's) in the code directory they should be in but
other than that any non-code/art docs should go in the design directory.
[JB]